# Fairyclient – changes

Package assumed: `com.fairyclient` (change `package`/`R` import if yours differs).

1. Copy `res/*` into `app/src/main/res/` (launcher icons + itachi_lineart.png + logo).
2. Copy `kotlin/*.kt` into `app/src/main/java/com/fairyclient/ui/`.
3. Manifest: `android:icon="@mipmap/ic_launcher"` `android:roundIcon="@mipmap/ic_launcher_round"`.
4. NavHost: start at `SplashScreen(onDone = { nav.navigate("home"){ popUpTo(0) } })`.
5. Settings tab: use `SettingsScreen(...)`. Remove the old "About >" row and the About route/screen.
6. Home: replace Force bootloader card with `ForceBootloaderCard(...)`; DA picker = `OpenDocument` launcher.
