package com.fairyclient.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.Text
import com.fairyclient.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Pure AMOLED black. No red glow. Itachi slides in from bottom-left like the girl in Fairy Flasher X. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val titleAlpha = remember { Animatable(0f) }
    val titleSpacing = remember { Animatable(14f) }      // differs from video: letters tighten in
    val itachi = remember { Animatable(0f) }
    var logoDone by remember { mutableStateOf(false) }
    val screenH = LocalConfiguration.current.screenHeightDp

    LaunchedEffect(Unit) {
        delay(900)
        itachi.animateTo(1f, tween(1300, easing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)))
    }
    LaunchedEffect(logoDone) {
        if (!logoDone) return@LaunchedEffect
        launch { titleAlpha.animateTo(1f, tween(700)) }
        titleSpacing.animateTo(4f, tween(900, easing = FastOutSlowInEasing))
        delay(1400)
        onDone()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Itachi: bottom-left, slides up + fades in
        Image(
            painter = painterResource(R.drawable.itachi_lineart),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .height((screenH * 0.40f).dp)
                .offset(x = (-24).dp, y = ((1f - itachi.value) * 220).dp)
                .alpha(itachi.value)
        )
        Column(
            Modifier.fillMaxSize().padding(bottom = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AnimatedFairyLogo(width = 230.dp, onFinished = { logoDone = true })
            Spacer(Modifier.height(36.dp))
            Text(
                "FAIRY CLIENT",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = titleSpacing.value.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(titleAlpha.value)
            )
        }
    }
}
