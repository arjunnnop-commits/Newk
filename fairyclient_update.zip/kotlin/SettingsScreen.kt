package com.fairyclient.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Pink = Color(0xFFFF6B7A)
private val Glass = Color(0x14FFFFFF)

/**
 * Settings: Storage + Community cards, then the About block rendered INLINE
 * (where the old "About >" row used to be). No separate About page, no version line.
 */
@Composable
fun SettingsScreen(
    savedFiles: Int,
    onClear: () -> Unit,
    onJoinTelegram: () -> Unit,
) {
    Column(Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Settings", fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Fairyclient preferences", color = Color(0xFFAAAAAA), fontSize = 18.sp)
        Spacer(Modifier.height(20.dp))

        GlassCard {
            Label("STORAGE")
            Text("$savedFiles saved file(s) in private app storage\nFirmware images are read straight from your storage and never copied.", color = Color(0xFFBBBBBB))
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("Clear saved files", color = Color.White) }
        }
        Spacer(Modifier.height(14.dp))
        GlassCard {
            Label("COMMUNITY")
            Text("Updates and support on the Fairy Team channel.", color = Color(0xFFBBBBBB))
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onJoinTelegram, modifier = Modifier.fillMaxWidth()) { Text("Join Telegram channel", color = Color.White) }
        }
        Spacer(Modifier.height(14.dp))
        AboutBlock(onJoinTelegram)
        Spacer(Modifier.height(120.dp)) // bottom nav space
    }
}

@Composable
fun AboutBlock(onJoinTelegram: () -> Unit) {
    // staggered reveal like Fairy Flasher X About
    var stage by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { delay(150); stage = 1; delay(1700); stage = 2; delay(250); stage = 3 }
    val cardAlpha by animateFloatAsState(if (stage >= 2) 1f else 0f, tween(500), label = "card")
    val tagAlpha by animateFloatAsState(if (stage >= 3) 1f else 0f, tween(500), label = "tag")

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        if (stage >= 1) AnimatedFairyLogo(width = 190.dp)
        else Spacer(Modifier.height(170.dp))
        Spacer(Modifier.height(12.dp))
        Text("FAIRYCLIENT", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp,
            letterSpacing = 5.sp, modifier = Modifier.alpha(cardAlpha))
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.alpha(cardAlpha)) {
            InfoRow("Built by", "@yooitachiijod", Color(0xFF9A9A9A))
            Divider(color = Color(0x22FFFFFF))
            InfoRow("Telegram", "Join Channel", Pink, onClick = onJoinTelegram)
            Divider(color = Color(0x22FFFFFF))
            InfoRow("Theme", "Liquid Glass · AMOLED", Pink)
            // Version row intentionally removed (single build)
        }
        Spacer(Modifier.height(16.dp))
        Text("Power  •  Control  •  Freedom", color = Color(0xFFAAAAAA), modifier = Modifier.alpha(tagAlpha))
        Spacer(Modifier.height(10.dp))
        Text("Flashing can damage your device. You are responsible for what you flash.",
            color = Color(0xFF777777), fontSize = 13.sp, modifier = Modifier.alpha(tagAlpha))
    }
}

@Composable private fun Label(t: String) = Text(t, color = Pink, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, modifier = Modifier.padding(bottom = 8.dp))

@Composable private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Glass).padding(20.dp), content = content)

@Composable private fun InfoRow(k: String, v: String, vc: Color, onClick: (() -> Unit)? = null) =
    Row(
        Modifier.fillMaxWidth().padding(vertical = 14.dp).let { if (onClick != null) it.clickableNoRipple(onClick) else it },
        horizontalArrangement = Arrangement.SpaceBetween
    ) { Text(k, color = Color.White, fontSize = 17.sp); Text(v, color = vc, fontWeight = FontWeight.SemiBold, fontSize = 17.sp) }

private fun Modifier.clickableNoRipple(onClick: () -> Unit) =
    this.then(Modifier.clickable(indication = null, interactionSource = androidx.compose.foundation.interaction.MutableInteractionSource(), onClick = onClick))
