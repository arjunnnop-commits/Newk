package com.fairyclient.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Force bootloader session.
 * Order: 1) DA (main, REQUIRED)  2) boot.img  3) vendor_boot.img
 * START stays disabled until a DA is selected.
 */
@Composable
fun ForceBootloaderCard(
    daName: String?, bootName: String?, vendorBootName: String?,
    running: Boolean, progress: Float,
    onPickDa: () -> Unit, onPickBoot: () -> Unit, onPickVendorBoot: () -> Unit,
    onStart: () -> Unit, onStop: () -> Unit,
) {
    val canStart = daName != null && !running
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(0x14FFFFFF)).padding(20.dp)) {
        Text("SESSION", color = Color(0xFFFF6B7A), fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text("Force bootloader", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Catches the phone in Preloader, forces fastboot, then flashes boot and vendor_boot.", color = Color(0xFF999999))
        Spacer(Modifier.height(14.dp))

        FileSlot("DA (Download Agent) — required", daName, "Select DA", onPickDa, required = true)
        FileSlot("boot.img", bootName, "Select boot.img", onPickBoot)
        FileSlot("vendor_boot.img", vendorBootName, "Select vendor_boot.img", onPickVendorBoot)

        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onStart, enabled = canStart, modifier = Modifier.weight(1f).height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE31C2F))) { Text("START", fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = onStop, enabled = running, modifier = Modifier.weight(1f).height(56.dp)) { Text("STOP") }
        }
        Spacer(Modifier.height(8.dp))
        when {
            daName == null -> Text("Select the DA first — it is required to start.", color = Color(0xFFFFB300))
            bootName == null && vendorBootName == null ->
                Text("No images selected — the phone will only be put into fastboot.", color = Color(0xFFFFB300))
        }
    }
}

@Composable
private fun FileSlot(label: String, name: String?, btn: String, onPick: () -> Unit, required: Boolean = false) {
    Text(label, color = Color(0xFFBBBBBB))
    Text(name ?: "Not selected", fontSize = 20.sp, fontWeight = FontWeight.Bold,
        color = if (name == null && required) Color(0xFFFF6B7A) else Color.White)
    OutlinedButton(onClick = onPick, modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp).height(52.dp)) { Text(btn, color = Color.White) }
}
