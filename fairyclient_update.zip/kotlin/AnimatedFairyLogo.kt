package com.fairyclient.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp

private val StrokeColor = Color(0xFFFF9AA5)

/**
 * Fairy logo animation (same sequence as Fairy Flasher X):
 *  1) outline draws itself (pink stroke)  2) white fill fades in, stroke fades out
 *  3) soft white pulse. No red background glow.
 */
@Composable
fun AnimatedFairyLogo(
    width: Dp,
    modifier: Modifier = Modifier,
    drawMillis: Int = 1100,
    fillMillis: Int = 550,
    onFinished: () -> Unit = {},
) {
    val path = remember { LogoPath.build() }
    val measure = remember { PathMeasure().also { it.setPath(path, false) } }
    val draw = remember { Animatable(0f) }
    val fill = remember { Animatable(0f) }
    val pulse = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        draw.animateTo(1f, tween(drawMillis, easing = FastOutSlowInEasing))
        fill.animateTo(1f, tween(fillMillis, easing = LinearEasing))
        pulse.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
        pulse.animateTo(0f, tween(450, easing = FastOutSlowInEasing))
        onFinished()
    }

    Canvas(modifier.size(width, width * (LogoPath.H / LogoPath.W))) {
        val s = size.width / LogoPath.W
        withTransform({ scale(s, s, pivot = Offset.Zero) }) {
            val len = measure.length
            if (fill.value < 1f) {
                val seg = Path()
                measure.getSegment(0f, len * draw.value, seg, true)
                val a = 1f - fill.value
                drawPath(seg, StrokeColor.copy(alpha = 0.25f * a),
                    style = Stroke(width = 4f / s * 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(seg, StrokeColor.copy(alpha = a),
                    style = Stroke(width = 1.4f / s * 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            if (fill.value > 0f) {
                drawPath(path, Color.White.copy(alpha = fill.value))
                if (pulse.value > 0f)
                    drawPath(path, Color.White.copy(alpha = 0.18f * pulse.value),
                        style = Stroke(width = 6f * pulse.value / s * 3f))
            }
        }
    }
}
