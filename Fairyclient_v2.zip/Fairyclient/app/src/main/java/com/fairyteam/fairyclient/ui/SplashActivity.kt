package com.fairyteam.fairyclient.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.fairyteam.fairyclient.R

/**
 * Open animation: logo outline draws -> fills; Itachi slides in from the bottom-left;
 * title "FAIRY CLIENT" fades in with its letters tightening. Then hands off to MainActivity.
 */
class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var launched = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logo = findViewById<FairyLogoView>(R.id.splashLogo)
        val title = findViewById<TextView>(R.id.splashTitle)
        val itachi = findViewById<ImageView>(R.id.splashItachi)
        val dp = resources.displayMetrics.density

        itachi.translationY = 240 * dp
        handler.postDelayed({
            itachi.animate().translationY(0f).alpha(1f).setDuration(1300)
                .setInterpolator(PathInterpolator(0.2f, 0.8f, 0.2f, 1f)).start()
        }, 900)

        handler.postDelayed({
            logo.play {
                ObjectAnimator.ofFloat(title, "alpha", 0f, 1f).apply { duration = 700; start() }
                ValueAnimator.ofFloat(0.5f, 0.18f).apply {
                    duration = 900
                    interpolator = DecelerateInterpolator()
                    addUpdateListener { title.letterSpacing = it.animatedValue as Float }
                    start()
                }
                handler.postDelayed({ goHome() }, 1500)
            }
        }, 150)

        // safety net so the app never gets stuck on the splash
        handler.postDelayed({ goHome() }, 6000)
    }

    private fun goHome() {
        if (launched || isFinishing) return
        launched = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
