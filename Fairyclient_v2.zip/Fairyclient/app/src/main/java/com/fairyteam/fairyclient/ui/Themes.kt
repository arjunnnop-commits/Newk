package com.fairyteam.fairyclient.ui

import android.content.Context
import com.fairyteam.fairyclient.R

/** The three liquid-glass AMOLED themes. Index is stored in preferences. */
object Themes {
    val names = listOf("Crimson Glass", "Matrix Glass", "Mono Glass")

    fun current(ctx: Context): Int =
        ctx.getSharedPreferences("fairy_ui", Context.MODE_PRIVATE).getInt("theme", 0).coerceIn(0, names.size - 1)

    fun save(ctx: Context, index: Int) {
        ctx.getSharedPreferences("fairy_ui", Context.MODE_PRIVATE).edit().putInt("theme", index).apply()
    }

    fun styleRes(index: Int): Int = when (index) {
        1 -> R.style.Theme_Fairyclient_Matrix
        2 -> R.style.Theme_Fairyclient_Mono
        else -> R.style.Theme_Fairyclient
    }
}
