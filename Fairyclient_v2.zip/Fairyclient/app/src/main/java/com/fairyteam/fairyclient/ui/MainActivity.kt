package com.fairyteam.fairyclient.ui

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.util.TypedValue
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.AttrRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.fairyteam.fairyclient.R
import com.fairyteam.fairyclient.brom.AutoFlow
import com.fairyteam.fairyclient.brom.DeviceInfo
import com.fairyteam.fairyclient.brom.FlashJob
import com.fairyteam.fairyclient.brom.Mode
import com.fairyteam.fairyclient.brom.Phase
import com.fairyteam.fairyclient.data.FileStore
import com.fairyteam.fairyclient.data.Kind
import com.fairyteam.fairyclient.databinding.ActivityMainBinding
import com.fairyteam.fairyclient.usb.UsbPermissions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class NavItem(val root: View, val icon: ImageView, val label: TextView, val panel: MainActivity.Panel?)

class MainActivity : AppCompatActivity() {

    enum class Panel { HOME, LOG, THEME, ABOUT }

    private lateinit var b: ActivityMainBinding
    private lateinit var usb: UsbManager
    private lateinit var perms: UsbPermissions
    private lateinit var store: FileStore
    private lateinit var flow: AutoFlow

    private var armJob: Job? = null
    private var armed = false
    private var mode = Mode.FASTBOOT
    private var panel = Panel.HOME
    private var info = DeviceInfo()
    private var steps = 0
    private var stepFailed = false
    private val logLines = ArrayDeque<String>()
    private lateinit var navItems: List<NavItem>

    private val pickers = Kind.values().associateWith { kind ->
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importFile(kind, uri)
        }
    }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) importFirmware(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(Themes.styleRes(Themes.current(this)))
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        store = FileStore(this)
        perms = UsbPermissions(this, usb)
        perms.register()
        flow = AutoFlow(
            usb, perms, ::log, ::showPhase, ::showProgress,
            onStep = ::onStep, onInfo = ::onInfo
        )

        // ---- file pickers ----
        b.btnPickDa.setOnClickListener { pickers[Kind.DA]?.launch(arrayOf("*/*")) }
        b.btnPickAuth.setOnClickListener { pickers[Kind.AUTH]?.launch(arrayOf("*/*")) }
        b.btnClearAuth.setOnClickListener {
            if (!armed) { store.remove(Kind.AUTH); refreshFiles() }
        }
        b.btnPickSingleImg.setOnClickListener { pickers[Kind.SINGLE_IMG]?.launch(arrayOf("*/*")) }
        b.btnPickFirmware.setOnClickListener { folderPicker.launch(null) }
        b.etPartitionName.doAfterTextChanged { updateStartState() }

        // ---- start / stop ----
        b.btnStart.setOnClickListener { onStartPressed() }
        b.btnStop.setOnClickListener { armJob?.cancel() }
        b.btnClear.setOnClickListener {
            if (!armed) { store.clear(); refreshFiles(); log("Saved files cleared.") }
        }
        b.btnClearLog.setOnClickListener {
            logLines.clear(); b.consoleText.text = ""
        }

        // ---- navigation ----
        navItems = listOf(
            NavItem(b.navHome, b.icHome, b.navHomeLbl, Panel.HOME),
            NavItem(b.navLog, b.icLog, b.navLogLbl, Panel.LOG),
            NavItem(b.navTheme, b.icTheme, b.navThemeLbl, Panel.THEME),
            NavItem(b.navAbout, b.icAbout, b.navAboutLbl, Panel.ABOUT),
            NavItem(b.navChannel, b.icChannel, b.navChannelLbl, null)
        )
        b.navHome.setOnClickListener { showPanel(Panel.HOME) }
        b.navLog.setOnClickListener { showPanel(Panel.LOG) }
        b.navTheme.setOnClickListener { showPanel(Panel.THEME) }
        b.navAbout.setOnClickListener { showPanel(Panel.ABOUT) }
        b.navChannel.setOnClickListener { openChannel() }
        b.btnAbout.setOnClickListener { showPanel(Panel.ABOUT) }
        b.aboutPanel.btnAboutBack.setOnClickListener { showPanel(Panel.HOME) }
        b.aboutPanel.rowTelegram.setOnClickListener { openChannel() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (panel != Panel.HOME) showPanel(Panel.HOME)
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        // ---- themes ----
        val cards = listOf(b.themeCard0, b.themeCard1, b.themeCard2)
        val tags = listOf(b.themeTag0, b.themeTag1, b.themeTag2)
        val cur = Themes.current(this)
        tags.forEachIndexed { i, t -> t.visibility = if (i == cur) View.VISIBLE else View.GONE }
        cards.forEachIndexed { i, c ->
            c.setOnClickListener {
                when {
                    armed -> Toast.makeText(this, "Stop the session before changing the theme.", Toast.LENGTH_SHORT).show()
                    i != Themes.current(this) -> { Themes.save(this, i); recreate() }
                }
            }
        }

        // ---- modes ----
        b.chipModes.setOnCheckedStateChangeListener { _, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            mode = when (id) {
                R.id.chipDa -> Mode.DA
                R.id.chipFirmware -> Mode.FIRMWARE
                R.id.chipSingleImg -> Mode.SINGLE_IMG
                R.id.chipReset -> Mode.RESET_DEVICE
                else -> Mode.FASTBOOT
            }
            applyModeUi()
        }

        // ---- restore after theme change ----
        val restored = savedInstanceState != null
        if (restored) {
            savedInstanceState?.getStringArrayList("log")?.let { logLines.addAll(it) }
            b.consoleText.text = logLines.joinToString("\n")
            panel = Panel.values()[savedInstanceState?.getInt("panel", 0) ?: 0]
            val m = runCatching { Mode.valueOf(savedInstanceState?.getString("mode") ?: "") }.getOrDefault(Mode.FASTBOOT)
            b.chipModes.check(
                when (m) {
                    Mode.DA -> R.id.chipDa
                    Mode.FIRMWARE -> R.id.chipFirmware
                    Mode.SINGLE_IMG -> R.id.chipSingleImg
                    Mode.RESET_DEVICE -> R.id.chipReset
                    else -> R.id.chipForceBoot
                }
            )
        } else {
            b.chipModes.check(R.id.chipForceBoot)
        }
        b.panelLog.visibility = if (panel == Panel.LOG) View.VISIBLE else View.GONE
        b.panelTheme.visibility = if (panel == Panel.THEME) View.VISIBLE else View.GONE
        b.aboutPanel.root.visibility = if (panel == Panel.ABOUT) View.VISIBLE else View.GONE
        updateNav()

        applyModeUi()
        refreshFiles()
        renderInfo()
        updateSteps()
        showProgress(0)
        if (!restored) {
            log("Ready. Choose an action, pick the files it needs, press START, then plug the phone in.")
            log("Tip: when Android asks what to open for the USB device, choose Fairyclient and tick \u201CUse by default\u201D \u2014 after that there is no popup.")
        }

        // Launched by the phone itself being plugged in → arm immediately.
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) startArm()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("panel", panel.ordinal)
        outState.putString("mode", mode.name)
        outState.putStringArrayList("log", ArrayList(logLines))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED && armJob?.isActive != true) startArm()
    }

    // ---- theme helpers -----------------------------------------------------

    private fun attrColor(@AttrRes attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    // ---- navigation --------------------------------------------------------

    private fun showPanel(p: Panel) {
        val prev = panel
        panel = p
        fun fadeIn(v: View) {
            if (v.visibility == View.VISIBLE && v.alpha == 1f) return
            v.animate().cancel()
            v.alpha = 0f
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(180).start()
        }
        fun fadeOut(v: View) {
            if (v.visibility != View.VISIBLE) return
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(150).withEndAction { v.visibility = View.GONE }.start()
        }
        listOf(Panel.LOG to b.panelLog, Panel.THEME to b.panelTheme, Panel.ABOUT to b.aboutPanel.root)
            .forEach { (k, v) -> if (k == p) fadeIn(v) else fadeOut(v) }
        updateNav()

        if (p == Panel.ABOUT && prev != Panel.ABOUT) {
            val a = b.aboutPanel
            val reveal = listOf(a.aboutTitle, a.aboutCard, a.aboutTagline, a.aboutDisclaimer)
            reveal.forEach { it.alpha = 0f; it.translationY = 18f }
            a.aboutLogo.play {
                reveal.forEachIndexed { i, v ->
                    v.animate().alpha(1f).translationY(0f).setStartDelay(i * 120L).setDuration(380).start()
                }
            }
        }
    }

    private fun updateNav() {
        val accent = attrColor(R.attr.fcAccent)
        val faint = attrColor(R.attr.fcTextSecondary)
        navItems.forEach { n ->
            val sel = n.panel == panel
            n.icon.imageTintList = ColorStateList.valueOf(if (sel) accent else faint)
            n.label.visibility = if (sel) View.VISIBLE else View.GONE
            n.root.setBackgroundResource(if (sel) R.drawable.nav_item_selected else 0)
        }
    }

    private fun openChannel() =
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.telegram_url))))

    // ---- mode UI -------------------------------------------------------

    private fun applyModeUi() {
        val reset = mode == Mode.RESET_DEVICE
        b.rowDa.visibility = if (reset) View.GONE else View.VISIBLE
        b.rowFirmware.visibility = if (mode == Mode.FIRMWARE) View.VISIBLE else View.GONE
        b.rowSingle.visibility = if (mode == Mode.SINGLE_IMG) View.VISIBLE else View.GONE
        b.rowResetWarning.visibility = if (reset) View.VISIBLE else View.GONE
        b.rowAuth.visibility = if (reset) View.GONE else View.VISIBLE

        b.tvModeHint.text = when (mode) {
            Mode.FASTBOOT -> "Catches the phone in BROM/Preloader and forces it into fastboot. Select the DA first (required)."
            Mode.DA -> "BROM handshake \u2192 chip ID \u2192 security flags \u2192 uploads DA1 and jumps to it. Partition writing through the DA is not implemented yet."
            Mode.FIRMWARE -> "Forces fastboot, then flashes every .img in the images folder you select."
            Mode.SINGLE_IMG -> "Forces fastboot, then writes one image to exactly one partition you name \u2014 recovery, dtbo, logo, etc."
            Mode.RESET_DEVICE -> "Forces fastboot, then erases userdata + cache. This is a factory data reset, not an account or lock bypass."
        }

        val daDone = listOf("USB\nDetected", "BROM\nHandshake", "Sending\nDA", "DA\nReady")
        val fbDone = listOf("USB\nDetected", "Force\nFastboot", "Fastboot\nReady", "Task\nDone")
        val lbl = if (mode == Mode.DA) daDone else fbDone
        listOf(b.stepLbl1, b.stepLbl2, b.stepLbl3, b.stepLbl4).forEachIndexed { i, t -> t.text = lbl[i] }

        refreshFiles()
    }

    // ---- start / stop ----------------------------------------------------

    private fun onStartPressed() {
        if (armed) return
        if (mode == Mode.RESET_DEVICE) {
            AlertDialog.Builder(this)
                .setTitle("Erase this device?")
                .setMessage("This wipes userdata and cache. It cannot be undone. Continue?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Erase") { _, _ -> startArm() }
                .show()
        } else {
            startArm()
        }
    }

    private fun startArm() {
        if (armJob?.isActive == true) return
        val da = store.file(Kind.DA)
        if (mode != Mode.RESET_DEVICE && da == null) {
            showPhase(Phase.FAILED, "Select DA first", "The DA file is required \u2014 tap Select DA File.")
            return
        }
        if (mode == Mode.FIRMWARE && store.firmwareFiles().isEmpty()) {
            showPhase(Phase.FAILED, "Select firmware", "Tap Select Images Folder and pick the folder with the .img files.")
            return
        }
        val partitionName = b.etPartitionName.text?.toString()?.trim()
        val singleImg = store.file(Kind.SINGLE_IMG)
        if (mode == Mode.SINGLE_IMG && (partitionName.isNullOrEmpty() || singleImg == null)) {
            showPhase(Phase.FAILED, "Missing info", "Single IMG needs a partition name and an image file.")
            return
        }
        val job = FlashJob(
            mode = mode,
            da = da,
            firmware = if (mode == Mode.FIRMWARE) store.firmwareFiles() else emptyList(),
            auth = store.file(Kind.AUTH),
            partitionName = partitionName,
            singleImg = singleImg
        )
        info = DeviceInfo()
        renderInfo()
        steps = 0; stepFailed = false
        setArmed(true)
        armJob = lifecycleScope.launch {
            try {
                flow.run(job)
            } catch (e: CancellationException) {
                showPhase(Phase.IDLE, "Fairy session stopped", "Press START to arm again.")
                showProgress(0)
                throw e
            } finally {
                setArmed(false)
            }
        }
    }

    private fun setArmed(value: Boolean) {
        armed = value
        b.chipModes.isEnabled = !value
        for (i in 0 until b.chipModes.childCount) b.chipModes.getChildAt(i).isEnabled = !value
        if (value) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        updateStartState()
        updateSteps()
    }

    private fun updateStartState() {
        val missing = when {
            mode == Mode.RESET_DEVICE -> null
            store.file(Kind.DA) == null -> "Select a DA file to start a Fairy session."
            mode == Mode.FIRMWARE && store.firmwareFiles().isEmpty() -> "Select the firmware images folder to flash."
            mode == Mode.SINGLE_IMG && (b.etPartitionName.text.isNullOrBlank() || store.file(Kind.SINGLE_IMG) == null) ->
                "Enter a partition name and select the image file."
            else -> null
        }
        b.tvStartHint.text = when {
            armed -> "Armed \u2014 plug the phone in now."
            missing != null -> missing
            else -> "Ready. Press START, then plug the phone in."
        }
        b.tvStartHint.setTextColor(attrColor(if (missing != null && !armed) R.attr.fcWarn else R.attr.fcTextSecondary))
        val canStart = !armed && missing == null
        b.btnStart.isEnabled = canStart
        b.btnStart.alpha = if (canStart) 1f else 0.4f
        b.btnStop.isEnabled = armed
        b.btnStop.alpha = if (armed) 1f else 0.4f
    }

    // ---- files -----------------------------------------------------------

    private fun importFile(kind: Kind, uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { store.import(kind, uri) }
            log(if (ok) "${kind.label} saved." else "Could not read ${kind.label}.")
            refreshFiles()
        }
    }

    private fun importFirmware(tree: Uri) {
        lifecycleScope.launch {
            log("Copying firmware images\u2026")
            showPhase(Phase.WORKING, "Reading firmware folder", "Copying .img files")
            showProgress(-1)
            val n = withContext(Dispatchers.IO) { store.importFirmware(tree) { name -> log("  + $name") } }
            showProgress(0)
            when {
                n > 0 -> { log("Firmware folder ready: $n images."); showPhase(Phase.IDLE, "Fairy session stopped", "Firmware folder ready \u2014 press START.") }
                n == 0 -> { log("No .img files found in that folder."); showPhase(Phase.FAILED, "No images found", "That folder has no .img files.") }
                else -> { log("Could not read that folder."); showPhase(Phase.FAILED, "Folder unreadable", "Pick the folder again.") }
            }
            refreshFiles()
        }
    }

    private fun refreshFiles() {
        fun set(tv: TextView, text: String?, empty: String) {
            tv.text = text ?: empty
            tv.setTextColor(attrColor(if (text != null) R.attr.fcAccent else R.attr.fcText))
        }
        set(b.tvDaName, store.describe(Kind.DA), "Not configured")
        set(b.tvAuthName, store.describe(Kind.AUTH), "Not selected \u2022 Optional")
        set(b.tvSingleImgName, store.describe(Kind.SINGLE_IMG), "Not selected")
        set(b.tvFirmwareName, store.firmwareDescribe(), "Not configured")
        b.tvTopDa.text = store.displayName(Kind.DA) ?: "Not configured"
        updateStartState()
    }

    // ---- card rendering ----------------------------------------------------

    private fun renderInfo() {
        fun dash(s: String?) = s ?: "\u2014"
        b.tvMode.text = info.mode ?: "NO DEVICE"
        b.tvCpu.text = dash(info.cpu)
        b.tvVidPid.text = dash(info.vidPid)
        b.tvStorage.text = "\u2014"
        b.tvProtocol.text = dash(info.protocol)
        b.tvMeid.text = "\u2014"
        b.tvSocId.text = "\u2014"
        fun flag(tv: TextView, v: Boolean?) {
            tv.text = when (v) { true -> "ON"; false -> "OFF"; null -> "\u2014" }
            tv.setTextColor(attrColor(when (v) { true -> R.attr.fcWarn; false -> R.attr.fcOk; null -> R.attr.fcTextSecondary }))
        }
        flag(b.tvSbc, info.sbc); flag(b.tvSla, info.sla); flag(b.tvDaa, info.daa)
    }

    private fun updateSteps() {
        val dots = listOf(b.stepDot1, b.stepDot2, b.stepDot3, b.stepDot4)
        dots.forEachIndexed { i, d ->
            d.setBackgroundResource(
                when {
                    i < steps -> R.drawable.step_done
                    i == steps && stepFailed -> R.drawable.step_fail
                    i == steps && armed -> R.drawable.step_active
                    else -> R.drawable.step_idle
                }
            )
        }
        val on = attrColor(R.attr.fcAccent)
        val off = attrColor(R.attr.fcTextFaint)
        listOf(b.stepLine1, b.stepLine2, b.stepLine3).forEachIndexed { i, l ->
            l.setBackgroundColor(if (steps >= i + 2) on else off)
        }
    }

    // ---- UI callbacks (safe from any thread) -----------------------------

    private fun ui(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else runOnUiThread { block() }
    }

    private fun onStep(n: Int, failed: Boolean) = ui {
        steps = n; stepFailed = failed
        updateSteps()
    }

    private fun onInfo(i: DeviceInfo) = ui {
        info = DeviceInfo(
            mode = i.mode ?: info.mode,
            vidPid = i.vidPid ?: info.vidPid,
            cpu = i.cpu ?: info.cpu,
            protocol = i.protocol ?: info.protocol,
            sbc = i.sbc ?: info.sbc,
            sla = i.sla ?: info.sla,
            daa = i.daa ?: info.daa
        )
        renderInfo()
    }

    private fun log(line: String) = ui {
        logLines.addLast(line)
        while (logLines.size > 400) logLines.removeFirst()
        b.consoleText.text = logLines.joinToString("\n")
        b.consoleScroll.post { b.consoleScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showPhase(p: Phase, title: String, sub: String) = ui {
        b.tvStatus.text = title
        b.tvStatusSub.text = sub
        b.tvStatus.setTextColor(
            attrColor(
                when (p) {
                    Phase.DONE -> R.attr.fcOk
                    Phase.WARN -> R.attr.fcWarn
                    Phase.FAILED -> R.attr.fcDanger
                    Phase.WORKING, Phase.CONNECTING -> R.attr.fcInfo
                    else -> R.attr.fcText
                }
            )
        )
        b.tvSession.text = when (p) {
            Phase.IDLE -> "STOPPED"
            Phase.WAITING -> "WAITING"
            Phase.CONNECTING, Phase.WORKING -> "RUNNING"
            Phase.DONE, Phase.WARN -> "COMPLETE"
            Phase.FAILED -> "FAILED"
        }
    }

    /** -1 = indeterminate, 0..100 = percent. */
    private fun showProgress(pct: Int) = ui {
        if (pct < 0) {
            if (!b.progress.isIndeterminate) b.progress.isIndeterminate = true
        } else {
            if (b.progress.isIndeterminate) b.progress.isIndeterminate = false
            b.progress.setProgressCompat(pct.coerceIn(0, 100), false)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        perms.unregister()
    }
}
