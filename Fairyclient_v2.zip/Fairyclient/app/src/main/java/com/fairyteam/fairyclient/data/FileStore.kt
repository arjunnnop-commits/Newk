package com.fairyteam.fairyclient.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileOutputStream

enum class Kind(val fileName: String, val label: String) {
    DA("da.bin", "DA file"),
    AUTH("auth.bin", "AUTH file"),
    SINGLE_IMG("single.img", "Single image")
}

/**
 * Keeps the picked DA / AUTH / single image and the firmware images folder inside the app's
 * private storage, so you pick them once and every later auto-run just uses them.
 */
class FileStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("fairy_files", Context.MODE_PRIVATE)
    private val dir = File(ctx.filesDir, "images").apply { mkdirs() }
    private val fwDir = File(ctx.filesDir, "firmware").apply { mkdirs() }

    fun file(k: Kind): File? = File(dir, k.fileName).takeIf { it.exists() && it.length() > 0 }

    fun displayName(k: Kind): String? = file(k)?.let { prefs.getString(k.name, k.fileName) }

    fun describe(k: Kind): String? {
        val f = file(k) ?: return null
        return "${prefs.getString(k.name, k.fileName)}  ·  ${size(f.length())}"
    }

    fun remove(k: Kind) {
        File(dir, k.fileName).delete()
        prefs.edit().remove(k.name).apply()
    }

    fun import(k: Kind, uri: Uri): Boolean {
        try {
            val tmp = File(dir, k.fileName + ".tmp")
            val input = ctx.contentResolver.openInputStream(uri) ?: return false
            input.use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o, 256 * 1024) } }
            val dst = File(dir, k.fileName)
            if (dst.exists()) dst.delete()
            if (!tmp.renameTo(dst)) return false
            val name = ctx.contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
            prefs.edit().putString(k.name, name ?: k.fileName).apply()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    // ---- firmware folder ---------------------------------------------------

    private val firstFlash = listOf("boot", "init_boot", "vendor_boot", "dtbo", "vbmeta", "vbmeta_system", "vbmeta_vendor")

    /** Imported .img files, in a sensible flashing order (boot-ish first, super last). */
    fun firmwareFiles(): List<File> {
        val all = fwDir.listFiles { f -> f.isFile && f.name.endsWith(".img", true) && f.length() > 0 }?.toList().orEmpty()
        fun key(f: File): Pair<Int, String> {
            val n = f.name.substringBeforeLast('.').lowercase()
            val rank = when {
                n in firstFlash -> firstFlash.indexOf(n)
                n == "super" -> 1000
                else -> 100
            }
            return rank to n
        }
        return all.sortedWith(compareBy({ key(it).first }, { key(it).second }))
    }

    fun firmwareDescribe(): String? {
        val l = firmwareFiles()
        if (l.isEmpty()) return null
        val name = prefs.getString("fw_name", "folder")
        return "$name  ·  ${l.size} images  ·  ${size(l.sumOf { it.length() })}"
    }

    /**
     * Copies every .img from the picked folder (or its "images" subfolder) into private storage.
     * Returns the number of images copied, 0 if the folder has none, -1 if it can't be read.
     */
    fun importFirmware(tree: Uri, onFile: (String) -> Unit): Int {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return -1
        fun imgs(d: DocumentFile) = d.listFiles().filter { it.isFile && (it.name ?: "").endsWith(".img", true) }
        var list = imgs(root)
        if (list.isEmpty()) {
            root.listFiles().firstOrNull { it.isDirectory && it.name.equals("images", true) }?.let { list = imgs(it) }
        }
        if (list.isEmpty()) return 0
        fwDir.listFiles()?.forEach { it.delete() }
        var n = 0
        for (d in list) {
            val name = File(d.name ?: continue).name
            val dst = File(fwDir, name)
            try {
                val input = ctx.contentResolver.openInputStream(d.uri) ?: continue
                input.use { i -> FileOutputStream(dst).use { o -> i.copyTo(o, 256 * 1024) } }
                n++
                onFile(name)
            } catch (e: Exception) {
                dst.delete()
            }
        }
        prefs.edit().putString("fw_name", root.name ?: "folder").apply()
        return n
    }

    fun clear() {
        Kind.values().forEach { File(dir, it.fileName).delete() }
        fwDir.listFiles()?.forEach { it.delete() }
        prefs.edit().clear().apply()
    }

    private fun size(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
        b >= 1 shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1 shl 10 -> "%.0f KB".format(b / 1024.0)
        else -> "$b B"
    }
}
