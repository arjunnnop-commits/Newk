package com.fairyteam.fairyclient.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.roundToInt

/**
 * Fairy logo with the Fairy Flasher X style intro:
 * outline draws itself (pink) -> white fill fades in -> soft pulse. No background glow.
 */
class FairyLogoView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val path = LogoPath.build()
    private val measure = PathMeasure(path, false)
    private val seg = Path()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    private var drawP = 1f
    private var fillP = 1f
    private var pulseP = 0f
    private var running: AnimatorSet? = null

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = resolveSize((160 * resources.displayMetrics.density).roundToInt(), wSpec)
        val h = (w * LogoPath.H / LogoPath.W).roundToInt()
        setMeasuredDimension(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        val s = width / LogoPath.W
        canvas.save()
        canvas.scale(s, s)
        if (fillP < 1f) {
            val a = 1f - fillP
            seg.rewind()
            measure.getSegment(0f, measure.length * drawP, seg, true)
            haloPaint.color = Color.argb((70 * a).toInt(), 255, 154, 165)
            haloPaint.strokeWidth = 4.4f / s * 2f
            canvas.drawPath(seg, haloPaint)
            linePaint.color = Color.argb((255 * a).toInt(), 255, 154, 165)
            linePaint.strokeWidth = 2.8f / s * 1.2f
            canvas.drawPath(seg, linePaint)
        }
        if (fillP > 0f) {
            fillPaint.alpha = (255 * fillP).toInt()
            canvas.drawPath(path, fillPaint)
            if (pulseP > 0f) {
                haloPaint.color = Color.argb((46 * pulseP).toInt(), 255, 255, 255)
                haloPaint.strokeWidth = 6f * pulseP / s * 2.5f
                canvas.drawPath(path, haloPaint)
            }
        }
        canvas.restore()
    }

    /** Plays the intro from the start. [onEnd] runs when the whole sequence has finished. */
    fun play(onEnd: (() -> Unit)? = null) {
        running?.cancel()
        drawP = 0f; fillP = 0f; pulseP = 0f
        invalidate()
        fun anim(from: Float, to: Float, ms: Long, ip: android.view.animation.Interpolator, onV: (Float) -> Unit) =
            ValueAnimator.ofFloat(from, to).apply {
                duration = ms; interpolator = ip
                addUpdateListener { onV(it.animatedValue as Float); invalidate() }
            }
        val draw = anim(0f, 1f, 1100, AccelerateDecelerateInterpolator()) { drawP = it }
        val fill = anim(0f, 1f, 550, LinearInterpolator()) { fillP = it }
        val up = anim(0f, 1f, 420, DecelerateInterpolator()) { pulseP = it }
        val down = anim(1f, 0f, 420, DecelerateInterpolator()) { pulseP = it }
        running = AnimatorSet().apply {
            playSequentially(draw, fill, up, down)
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) { if (!cancelled) onEnd?.invoke() }
            })
            start()
        }
    }

    override fun onDetachedFromWindow() {
        running?.cancel()
        super.onDetachedFromWindow()
    }
}
