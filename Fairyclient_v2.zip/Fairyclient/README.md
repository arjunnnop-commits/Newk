# Fairyclient

MediaTek BROM / Preloader recovery for Android (USB-OTG, no root).

* **Force bootloader** mode: catches the Preloader, asks it for fastboot, then flashes
  boot / vendor_boot with the standard fastboot protocol.
* **DA / BROM** mode: handshake, chip id, security flags (SBC/SLA/DAA), picks the right
  loader from an AllInOne DA automatically, uploads DA1 and jumps to it.
  (Partition writing through the DA is not implemented.)

Pick files once (they are stored privately), press START AUTO, plug the phone in.

First plug-in: choose Fairyclient in Android's USB dialog and tick "Use by default" —
afterwards the app opens with permission already granted (no popup).

## Layout (RaffXLink-style)

Home is one scrolling page: **USB Status** → **Connection Steps** → **Device Info** →
**Fairy Session** (DA file, optional AUTH file, START / STOP). The action row at the top is a
single line: Bootloader · DA / BROM · Firmware · Single IMG · Reset.
Bottom bar: Home · Log · Theme · About · Channel.

## Actions

* **Bootloader** — catches the Preloader, forces fastboot, stays there.
* **DA / BROM** — handshake, chip id, SBC/SLA/DAA flags, uploads DA1 and jumps to it.
  (Partition writing through the DA is not implemented.)
* **Firmware** — tap *Select Images Folder*, pick the folder with your `.img` files (an
  `images` subfolder is found automatically). After forcing fastboot, every `.img` is flashed
  to the partition named like the file (`boot.img` → `boot`). `preloader*` images are skipped.
* **Single IMG** — force bootloader, then `fastboot flash <partition> <file>`.
* **Reset** — force bootloader, then `erase userdata` + `erase cache`, with a confirmation.
  Factory data reset only; it does not touch FRP or a screen lock.

AUTH file is optional and only stored for DA mode (SLA auth is not implemented yet).
MEID, SoC ID and Storage show "—" because the app does not read them yet.

## Themes

Three liquid-glass themes on pure AMOLED black (Theme tab): Crimson Glass (default),
Matrix Glass, Mono Glass. Colours live in `values/colors.xml` / `values/themes.xml`.

**Not included:** FRP / Google-lock / screen-lock removal. That needs a signed, device-specific
bypass of the chip's own security checks (SLA/DAA), which this project does not implement, so
there's no chip for it in the UI — every action you see actually does what it says.

## UI / branding

Home, About and the splash screen were redesigned with a dark "liquid glass" look (frosted,
translucent cards over a dark gradient). The About screen shows the built-by handle and a
"Join Channel" row that opens the Telegram link in the user's browser/Telegram app. The
brand mark (shield + flash bolt) is original artwork made for this project — no third-party
character art is bundled, so swap `ic_brand_mark*.xml` / the launcher icon drawables for your
own licensed art if you want a character illustration instead.
