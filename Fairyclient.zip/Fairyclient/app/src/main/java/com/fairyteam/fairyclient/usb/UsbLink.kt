package com.fairyteam.fairyclient.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.SystemClock

/**
 * Bulk IN/OUT pipe over Android USB-host (no root).
 *
 * Reads go through an internal FIFO: the endpoint is always read with a
 * full-size buffer (never 1 byte), which avoids the "overflow" error some
 * phones give when the chip sends a longer packet than the buffer, and lets
 * callers ask for exactly N bytes with a timeout.
 */
class UsbLink(
    private val manager: UsbManager,
    val device: UsbDevice,
    private val accept: (UsbInterface) -> Boolean = { true }
) {
    private var connection: UsbDeviceConnection? = null
    private var claimed: UsbInterface? = null
    private var epIn: UsbEndpoint? = null
    private var epOut: UsbEndpoint? = null
    private var pending = ByteArray(0)
    private val chunk = ByteArray(4096)

    fun open(): Boolean {
        if (!manager.hasPermission(device)) return false
        val conn: UsbDeviceConnection? = try {
            manager.openDevice(device)
        } catch (e: Exception) {
            null
        }
        if (conn == null) return false

        var commId = -1
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            if (itf.interfaceClass == UsbConstants.USB_CLASS_COMM) commId = itf.id
        }

        // Match on "has one bulk IN + one bulk OUT", not on declared class:
        // MediaTek exposes its bulk pipe under different classes per stage.
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            if (!accept(itf)) continue
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
            }
            if (inEp != null && outEp != null && conn.claimInterface(itf, true)) {
                connection = conn
                claimed = itf
                epIn = inEp
                epOut = outEp
                if (commId >= 0) setupCdc(conn, commId)
                return true
            }
        }
        conn.close()
        return false
    }

    /** Best-effort CDC-ACM init (115200 8N1, DTR+RTS) — harmless if ignored. */
    private fun setupCdc(conn: UsbDeviceConnection, commId: Int) {
        val coding = byteArrayOf(0x00, 0xC2.toByte(), 0x01, 0x00, 0x00, 0x00, 0x08)
        conn.controlTransfer(0x21, 0x20, 0, commId, coding, coding.size, 200)
        conn.controlTransfer(0x21, 0x22, 0x03, commId, null, 0, 200)
    }

    fun close() {
        try {
            claimed?.let { connection?.releaseInterface(it) }
            connection?.close()
        } catch (_: Exception) {
        }
        connection = null
        claimed = null
    }

    fun write(data: ByteArray, timeoutMs: Int = 5000): Boolean = writeN(data, data.size, timeoutMs)

    fun writeN(data: ByteArray, length: Int, timeoutMs: Int = 5000): Boolean {
        val conn = connection ?: return false
        val ep = epOut ?: return false
        var off = 0
        while (off < length) {
            val len = minOf(16384, length - off)
            val n = conn.bulkTransfer(ep, data, off, len, timeoutMs)
            if (n <= 0) return false
            off += n
        }
        return true
    }

    /** Exactly [length] bytes or null on timeout. */
    fun read(length: Int, timeoutMs: Int): ByteArray? {
        val conn = connection ?: return null
        val ep = epIn ?: return null
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (pending.size < length) {
            val left = (deadline - SystemClock.elapsedRealtime()).toInt()
            if (left <= 0) break
            val n = conn.bulkTransfer(ep, chunk, chunk.size, left)
            if (n > 0) {
                pending += chunk.copyOf(n)
            } else if (SystemClock.elapsedRealtime() < deadline) {
                Thread.sleep(1)
            }
        }
        if (pending.size < length) return null
        val out = pending.copyOfRange(0, length)
        pending = pending.copyOfRange(length, pending.size)
        return out
    }

    fun readByte(timeoutMs: Int): Int {
        val r = read(1, timeoutMs) ?: return -1
        return r[0].toInt() and 0xFF
    }

    /** Whatever arrives next (up to [max] bytes), or null on timeout. */
    fun readAvailable(max: Int, timeoutMs: Int): ByteArray? {
        val conn = connection ?: return null
        val ep = epIn ?: return null
        if (pending.isEmpty()) {
            val n = conn.bulkTransfer(ep, chunk, chunk.size, timeoutMs)
            if (n <= 0) return null
            pending = chunk.copyOf(n)
        }
        val take = minOf(max, pending.size)
        val out = pending.copyOfRange(0, take)
        pending = pending.copyOfRange(take, pending.size)
        return out
    }
}
