package com.fairyteam.fairyclient.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

enum class Kind(val fileName: String, val label: String) {
    DA("da.bin", "DA file"),
    BOOT("boot.img", "boot.img"),
    VENDOR_BOOT("vendor_boot.img", "vendor_boot.img"),
    SINGLE_IMG("single.img", "Single image")
}

/**
 * Keeps the picked DA / boot / vendor_boot inside the app's private storage so
 * you pick them once and every later auto-run just uses them (no re-picking
 * each time the device is plugged in).
 */
class FileStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("fairy_files", Context.MODE_PRIVATE)
    private val dir = File(ctx.filesDir, "images").apply { mkdirs() }

    fun file(k: Kind): File? = File(dir, k.fileName).takeIf { it.exists() && it.length() > 0 }

    fun describe(k: Kind): String? {
        val f = file(k) ?: return null
        return "${prefs.getString(k.name, k.fileName)}  ·  ${size(f.length())}"
    }

    fun import(k: Kind, uri: Uri): Boolean {
        try {
            val tmp = File(dir, k.fileName + ".tmp")
            val input = ctx.contentResolver.openInputStream(uri) ?: return false
            input.use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o, 256 * 1024) } }
            val dst = File(dir, k.fileName)
            if (dst.exists()) dst.delete()
            if (!tmp.renameTo(dst)) return false
            val name = ctx.contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
            prefs.edit().putString(k.name, name ?: k.fileName).apply()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun clear() {
        Kind.values().forEach { File(dir, it.fileName).delete() }
        prefs.edit().clear().apply()
    }

    private fun size(b: Long): String = when {
        b >= 1 shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1 shl 10 -> "%.0f KB".format(b / 1024.0)
        else -> "$b B"
    }
}
