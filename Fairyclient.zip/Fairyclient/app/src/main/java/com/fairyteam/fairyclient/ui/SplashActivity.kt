package com.fairyteam.fairyclient.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.animation.DecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.fairyteam.fairyclient.R

/** Short branded open animation, then hands off to MainActivity. */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val mark = findViewById<android.widget.ImageView>(R.id.splashMark)
        val title = findViewById<android.widget.TextView>(R.id.splashTitle)
        val tag = findViewById<android.widget.TextView>(R.id.splashTag)

        val markIn = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(mark, "alpha", 0f, 1f),
                ObjectAnimator.ofFloat(mark, "scaleX", 0.7f, 1f),
                ObjectAnimator.ofFloat(mark, "scaleY", 0.7f, 1f)
            )
            duration = 480
            interpolator = DecelerateInterpolator()
        }
        val titleIn = ObjectAnimator.ofFloat(title, "alpha", 0f, 1f).apply { duration = 320 }
        val tagIn = ObjectAnimator.ofFloat(tag, "alpha", 0f, 1f).apply { duration = 320 }

        val sequence = AnimatorSet()
        sequence.playSequentially(markIn, titleIn, tagIn)
        sequence.startDelay = 120
        sequence.start()

        findViewById<android.view.View>(android.R.id.content).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1500)
    }
}
