package com.fairyteam.fairyclient.ui

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fairyteam.fairyclient.R
import com.fairyteam.fairyclient.brom.AutoFlow
import com.fairyteam.fairyclient.brom.FlashJob
import com.fairyteam.fairyclient.brom.Mode
import com.fairyteam.fairyclient.brom.Phase
import com.fairyteam.fairyclient.data.FileStore
import com.fairyteam.fairyclient.data.Kind
import com.fairyteam.fairyclient.databinding.ActivityMainBinding
import com.fairyteam.fairyclient.usb.UsbPermissions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var usb: UsbManager
    private lateinit var perms: UsbPermissions
    private lateinit var store: FileStore
    private lateinit var flow: AutoFlow

    private var armJob: Job? = null
    private var mode = Mode.FASTBOOT
    private val logLines = ArrayDeque<String>()

    private val pickers = Kind.values().associateWith { kind ->
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importFile(kind, uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        store = FileStore(this)
        perms = UsbPermissions(this, usb)
        perms.register()
        flow = AutoFlow(usb, perms, ::log, ::showPhase, ::showProgress)

        b.btnPickDa.setOnClickListener { pickers[Kind.DA]?.launch(arrayOf("*/*")) }
        b.btnPickBoot.setOnClickListener { pickers[Kind.BOOT]?.launch(arrayOf("*/*")) }
        b.btnPickVendorBoot.setOnClickListener { pickers[Kind.VENDOR_BOOT]?.launch(arrayOf("*/*")) }
        b.btnPickSingleImg.setOnClickListener { pickers[Kind.SINGLE_IMG]?.launch(arrayOf("*/*")) }
        b.btnArm.setOnClickListener { onArmPressed() }
        b.btnClear.setOnClickListener {
            if (armJob?.isActive != true) {
                store.clear(); refreshFiles(); log("Saved files cleared.")
            }
        }

        b.btnAbout.setOnClickListener { openAbout() }
        b.navAbout.setOnClickListener { openAbout() }
        b.navHome.setOnClickListener { /* already home */ }
        b.navChannel.setOnClickListener { openChannel() }

        b.chipModes.setOnCheckedStateChangeListener { _, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            mode = when (id) {
                R.id.chipDa -> Mode.DA
                R.id.chipFullFw -> Mode.FULL_FIRMWARE
                R.id.chipSingleImg -> Mode.SINGLE_IMG
                R.id.chipReset -> Mode.RESET_DEVICE
                else -> Mode.FASTBOOT
            }
            applyModeUi()
        }
        b.chipModes.check(R.id.chipForceBoot)
        applyModeUi()
        refreshFiles()
        showProgress(0)
        log("Ready. Choose an action, pick the files it needs, press START AUTO, then plug the phone in.")
        log("Tip: when Android asks what to open for the USB device, choose Fairyclient and tick \u201CUse by default\u201D \u2014 after that there is no popup.")

        // Launched by the phone itself being plugged in → arm immediately.
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) startArm()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED && armJob?.isActive != true) startArm()
    }

    // ---- navigation --------------------------------------------------------

    private fun openAbout() = startActivity(Intent(this, AboutActivity::class.java))

    private fun openChannel() =
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.telegram_url))))

    // ---- mode UI -------------------------------------------------------

    private fun applyModeUi() {
        b.rowPartitionName.visibility = if (mode == Mode.SINGLE_IMG) View.VISIBLE else View.GONE
        b.rowSingleImg.visibility = if (mode == Mode.SINGLE_IMG) View.VISIBLE else View.GONE
        b.rowResetWarning.visibility = if (mode == Mode.RESET_DEVICE) View.VISIBLE else View.GONE

        val hideFileRows = mode == Mode.RESET_DEVICE
        b.rowBoot.visibility = if (hideFileRows || mode == Mode.SINGLE_IMG) View.GONE else View.VISIBLE
        b.rowVendorBoot.visibility = if (hideFileRows || mode == Mode.SINGLE_IMG) View.GONE else View.VISIBLE
        b.rowDa.visibility = if (mode == Mode.DA) View.VISIBLE else View.GONE

        b.tvModeHint.text = when (mode) {
            Mode.FASTBOOT -> "Catches the phone in BROM/Preloader, forces fastboot, then flashes boot + vendor_boot."
            Mode.DA -> "BROM handshake \u2192 chip ID \u2192 security flags \u2192 uploads DA1 and jumps to it. Partition writing through the DA is not implemented yet."
            Mode.FULL_FIRMWARE -> "Same recovery path as Force bootloader, but intended for flashing every image you have for this device (boot + vendor_boot here; add more partitions with Single IMG as needed)."
            Mode.SINGLE_IMG -> "Forces fastboot, then writes one image to exactly one partition you name \u2014 useful for recovery, dtbo, logo, etc."
            Mode.RESET_DEVICE -> "Forces fastboot, then erases userdata + cache. This is a factory data reset, not an account or lock bypass."
        }

        b.btnArm.text = when (mode) {
            Mode.RESET_DEVICE -> "START AUTO (ERASE)"
            else -> "START AUTO"
        }
        refreshFiles()
    }

    // ---- arming ----------------------------------------------------------

    private fun onArmPressed() {
        if (armJob?.isActive == true) {
            armJob?.cancel()
            return
        }
        if (mode == Mode.RESET_DEVICE) {
            AlertDialog.Builder(this)
                .setTitle("Erase this device?")
                .setMessage("This wipes userdata and cache. It cannot be undone. Continue?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Erase") { _, _ -> startArm() }
                .show()
        } else {
            startArm()
        }
    }

    private fun startArm() {
        val da = store.file(Kind.DA)
        if (mode == Mode.DA && da == null) {
            showPhase(Phase.FAILED, "DA file missing", "DA mode needs a DA file \u2014 tap Select.")
            return
        }
        val partitionName = b.etPartitionName.text?.toString()?.trim()
        val singleImg = store.file(Kind.SINGLE_IMG)
        if (mode == Mode.SINGLE_IMG && (partitionName.isNullOrEmpty() || singleImg == null)) {
            showPhase(Phase.FAILED, "Missing info", "Single IMG mode needs a partition name and an image file.")
            return
        }
        val job = FlashJob(
            mode = mode,
            da = da,
            boot = store.file(Kind.BOOT),
            vendorBoot = store.file(Kind.VENDOR_BOOT),
            partitionName = partitionName,
            singleImg = singleImg
        )
        setArmed(true)
        armJob = lifecycleScope.launch {
            try {
                flow.run(job)
            } catch (e: CancellationException) {
                showPhase(Phase.IDLE, "Stopped", "Press START AUTO to arm again.")
                showProgress(0)
                throw e
            } finally {
                setArmed(false)
            }
        }
    }

    private fun setArmed(armed: Boolean) {
        b.btnArm.text = if (armed) "STOP" else if (mode == Mode.RESET_DEVICE) "START AUTO (ERASE)" else "START AUTO"
        b.btnArm.backgroundTintList = ColorStateList.valueOf(Color.parseColor(if (armed) "#FF5C5C" else "#00FF88"))
        b.chipModes.isEnabled = !armed
        for (i in 0 until b.chipModes.childCount) b.chipModes.getChildAt(i).isEnabled = !armed
        if (armed) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---- files -----------------------------------------------------------

    private fun importFile(kind: Kind, uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { store.import(kind, uri) }
            log(if (ok) "${kind.label} saved." else "Could not read ${kind.label}.")
            refreshFiles()
        }
    }

    private fun refreshFiles() {
        fun set(tv: TextView, k: Kind) {
            val d = store.describe(k)
            tv.text = d ?: "not selected"
            tv.setTextColor(Color.parseColor(if (d != null) "#00FF88" else "#9AA4B2"))
        }
        set(b.tvDaName, Kind.DA)
        set(b.tvBootName, Kind.BOOT)
        set(b.tvVendorBootName, Kind.VENDOR_BOOT)
        set(b.tvSingleImgName, Kind.SINGLE_IMG)
        b.lblDa.text = if (mode == Mode.DA) "DA file  (required)" else "DA file  (DA mode only)"
    }

    // ---- UI callbacks (safe from any thread) -----------------------------

    private fun ui(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else runOnUiThread { block() }
    }

    private fun log(line: String) = ui {
        logLines.addLast(line)
        while (logLines.size > 400) logLines.removeFirst()
        b.consoleText.text = logLines.joinToString("\n")
        b.consoleScroll.post { b.consoleScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    private fun showPhase(p: Phase, title: String, sub: String) = ui {
        b.tvStatus.text = title
        b.tvStatusSub.text = sub
        val c = when (p) {
            Phase.DONE -> "#00FF88"
            Phase.WARN -> "#FFB020"
            Phase.FAILED -> "#FF5C6C"
            Phase.WORKING, Phase.CONNECTING -> "#4DA3FF"
            else -> "#F3F5F8"
        }
        b.tvStatus.setTextColor(Color.parseColor(c))
    }

    /** -1 = indeterminate, 0..100 = percent. */
    private fun showProgress(pct: Int) = ui {
        if (pct < 0) {
            if (!b.progress.isIndeterminate) b.progress.isIndeterminate = true
        } else {
            if (b.progress.isIndeterminate) b.progress.isIndeterminate = false
            b.progress.setProgressCompat(pct.coerceIn(0, 100), false)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        perms.unregister()
    }
}
