package com.fairyteam.fairyclient.brom

import android.os.SystemClock
import com.fairyteam.fairyclient.usb.UsbLink

/**
 * MediaTek BROM / Preloader command layer (same wire format SP Flash Tool and
 * mtkclient use): every command byte and every 32-bit parameter is ECHOED back
 * by the chip, results are big-endian 16/32-bit words, status 0 = OK.
 *
 * Handshake is a tight polling loop (like SP Flash Tool): the chip only
 * listens for a short window after enumerating, so we hammer 0xA0 until the
 * 0x5F answer appears instead of doing a few slow attempts.
 */
class BromProtocol(private val link: UsbLink) {

    class BromException(message: String) : Exception(message)

    data class TargetConfig(val raw: Long) {
        val sbc get() = raw and 1L != 0L   // secure boot
        val sla get() = raw and 2L != 0L   // serial link authorization
        val daa get() = raw and 4L != 0L   // DA authentication
        override fun toString() =
            "SBC=${if (sbc) "ON" else "off"}  SLA=${if (sla) "ON" else "off"}  DAA=${if (daa) "ON" else "off"}"
    }

    companion object {
        const val CMD_JUMP_DA = 0xD5
        const val CMD_SEND_DA = 0xD7
        const val CMD_GET_TARGET_CONFIG = 0xD8
        const val CMD_GET_HW_CODE = 0xFD
    }

    fun handshake(timeoutMs: Long = 20000): Boolean {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        var writeFails = 0
        val a0 = byteArrayOf(0xA0.toByte())
        while (SystemClock.elapsedRealtime() < end) {
            if (!link.write(a0, 30)) {
                if (++writeFails > 300) return false   // device is gone
                Thread.sleep(2)
                continue
            }
            writeFails = 0
            if (link.readByte(12) != 0x5F) continue    // "READY" chatter etc.
            if (finishHandshake()) return true
        }
        return false
    }

    private fun finishHandshake(): Boolean {
        val steps = arrayOf(0x0A to 0xF5, 0x50 to 0xAF, 0x05 to 0xFA)
        for ((out, expect) in steps) {
            if (!link.write(byteArrayOf(out.toByte()), 200)) return false
            if (link.readByte(300) != expect) return false
        }
        return true
    }

    fun getHwCode(): Int {
        echo8(CMD_GET_HW_CODE, "GET_HW_CODE")
        val hw = readU16("hw code")
        val status = readU16("status")
        if (status != 0) throw BromException("GET_HW_CODE status 0x${status.toString(16)}")
        return hw
    }

    fun getTargetConfig(): TargetConfig {
        echo8(CMD_GET_TARGET_CONFIG, "GET_TARGET_CONFIG")
        val cfg = readU32("target config")
        val status = readU16("status")
        if (status > 0xFF) throw BromException("GET_TARGET_CONFIG status 0x${status.toString(16)}")
        return TargetConfig(cfg)
    }

    /**
     * [data] is the whole DA region (signature included, if any); [sigLen] says
     * how many trailing bytes of it are signature.
     */
    fun sendDa(address: Long, data: ByteArray, sigLen: Long, onProgress: (Int) -> Unit = {}) {
        echo8(CMD_SEND_DA, "SEND_DA")
        echo32(address, "DA address")
        echo32(data.size.toLong(), "DA length")
        echo32(sigLen, "DA signature length")
        val status = readU16("SEND_DA status")
        if (status != 0) {
            throw BromException(
                "BROM refused the DA header (status 0x${status.toString(16)}). " +
                    "Secure-boot device: DA must be signed / auth-bypassed."
            )
        }
        var off = 0
        while (off < data.size) {
            val len = minOf(4096, data.size - off)
            if (!link.write(data.copyOfRange(off, off + len), 5000))
                throw BromException("USB write failed while sending DA at $off")
            off += len
            onProgress(off * 100 / data.size)
        }
        readU16("DA checksum")
        val fin = readU16("SEND_DA final status")
        if (fin != 0) throw BromException("DA rejected after upload (status 0x${fin.toString(16)}) — wrong/unsigned DA for this chip")
    }

    fun jumpDa(address: Long) {
        echo8(CMD_JUMP_DA, "JUMP_DA")
        echo32(address, "jump address")
        val status = readU16("JUMP_DA status")
        if (status != 0) throw BromException("JUMP_DA status 0x${status.toString(16)}")
    }

    // ---- helpers -------------------------------------------------------

    private fun echo8(cmd: Int, name: String) {
        if (!link.write(byteArrayOf(cmd.toByte()), 1000)) throw BromException("$name: USB write failed")
        if (link.readByte(1000) != cmd) throw BromException("$name: chip did not echo command")
    }

    private fun echo32(v: Long, name: String) {
        val b = be32(v)
        if (!link.write(b, 1000)) throw BromException("$name: USB write failed")
        val r = link.read(4, 1000) ?: throw BromException("$name: no echo")
        if (!r.contentEquals(b)) throw BromException("$name: bad echo")
    }

    private fun readU16(what: String): Int {
        val r = link.read(2, 5000) ?: throw BromException("Timeout reading $what")
        return ((r[0].toInt() and 0xFF) shl 8) or (r[1].toInt() and 0xFF)
    }

    private fun readU32(what: String): Long {
        val r = link.read(4, 5000) ?: throw BromException("Timeout reading $what")
        var v = 0L
        for (x in r) v = (v shl 8) or (x.toLong() and 0xFF)
        return v
    }

    private fun be32(v: Long) = byteArrayOf(
        ((v shr 24) and 0xFF).toByte(), ((v shr 16) and 0xFF).toByte(),
        ((v shr 8) and 0xFF).toByte(), (v and 0xFF).toByte()
    )
}
