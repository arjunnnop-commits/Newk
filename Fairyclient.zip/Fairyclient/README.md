# Fairyclient

MediaTek BROM / Preloader recovery for Android (USB-OTG, no root).

* **Force bootloader** mode: catches the Preloader, asks it for fastboot, then flashes
  boot / vendor_boot with the standard fastboot protocol.
* **DA / BROM** mode: handshake, chip id, security flags (SBC/SLA/DAA), picks the right
  loader from an AllInOne DA automatically, uploads DA1 and jumps to it.
  (Partition writing through the DA is not implemented.)

Pick files once (they are stored privately), press START AUTO, plug the phone in.

First plug-in: choose Fairyclient in Android's USB dialog and tick "Use by default" —
afterwards the app opens with permission already granted (no popup).

## Actions (chip row on Home)

* **Force bootloader** — as above.
* **DA / BROM** — as above.
* **Full firmware flash** — same force-bootloader → fastboot path, meant for flashing every
  image you have for the device (currently boot + vendor_boot; extend with more
  partition/file pairs the same way Single IMG does if you need more at once).
* **Single IMG flash** — force bootloader, then `fastboot flash <partition> <file>` for one
  partition you name (recovery, dtbo, logo, …).
* **Reset device** — force bootloader, then `fastboot erase userdata` + `erase cache`, with a
  confirmation dialog first. This is a factory data reset; it does not touch FRP or a
  screen lock.
**Not included:** FRP / Google-lock / screen-lock removal. That needs a signed, device-specific
bypass of the chip's own security checks (SLA/DAA), which this project does not implement, so
there's no chip for it in the UI — every action you see actually does what it says.

## UI / branding

Home, About and the splash screen were redesigned with a dark "liquid glass" look (frosted,
translucent cards over a dark gradient). The About screen shows the built-by handle and a
"Join Channel" row that opens the Telegram link in the user's browser/Telegram app. The
brand mark (shield + flash bolt) is original artwork made for this project — no third-party
character art is bundled, so swap `ic_brand_mark*.xml` / the launcher icon drawables for your
own licensed art if you want a character illustration instead.
