# Fairyclient

MediaTek BROM / Preloader recovery for Android (USB-OTG, no root).

* **Force bootloader** mode: catches the Preloader, asks it for fastboot, then flashes
  boot / vendor_boot with the standard fastboot protocol.
* **DA / BROM** mode: handshake, chip id, security flags (SBC/SLA/DAA), picks the right
  loader from an AllInOne DA automatically, uploads DA1 and jumps to it.
  (Partition writing through the DA is not implemented.)

Pick files once (they are stored privately), press START AUTO, plug the phone in.

First plug-in: choose Fairyclient in Android's USB dialog and tick "Use by default" —
afterwards the app opens with permission already granted (no popup).

## Actions (chip row on Home)

* **Force bootloader** — as above.
* **DA / BROM** — as above.
* **Full firmware flash** — force bootloader, then flashes a whole firmware set partition by
  partition. Select the extracted firmware folder (or add image files); every `*.img` is listed
  with a checkbox (`boot.img` → `boot`, `super.img` → `super`, `vbmeta.img` → `vbmeta` …).
  `userdata` / `metadata` are listed but unticked by default. Vendor `*.img_sparsechunk.N` sets
  are flashed in order to one partition. Raw images bigger than the phone's
  `max-download-size` are split into sparse pieces on the fly (nothing is copied or written to
  disk); an already-sparse image above the limit is refused with a clear message.
* **Single IMG flash** — force bootloader, then `fastboot flash <partition> <file>` for one
  partition you name (recovery, dtbo, logo, …).
* **Reset device** — force bootloader, then `fastboot erase userdata` + `erase cache`, with a
  confirmation dialog first. This is a factory data reset; it does not touch FRP or a
  screen lock.
**Not included:** FRP / Google-lock / screen-lock removal. That needs a signed, device-specific
bypass of the chip's own security checks (SLA/DAA), which this project does not implement, so
there's no chip for it in the UI — every action you see actually does what it says.

## UI / branding

Pure-black AMOLED "liquid glass" theme (translucent cards, hairline highlights, crimson accent).
Layout follows the RaffXLink structure: **Home** (USB status, connection steps, device info,
session card with START/STOP) · **Menu** (pick the action) · **Console** (live log) ·
**Settings** (storage, Telegram, About), with a floating glass pill nav.
The About screen follows the Fairy Flasher X layout (animated logo, Built by / Telegram / Theme /
Version). The logo is `res/drawable-nodpi/logo_mark.png`; the launcher icon uses
`ic_launcher_fg.png` on a dark-red radial background (plus a themed monochrome layer).

Not compiled in the authoring environment — run the GitHub Actions build (or Android Studio)
and test on a device.
