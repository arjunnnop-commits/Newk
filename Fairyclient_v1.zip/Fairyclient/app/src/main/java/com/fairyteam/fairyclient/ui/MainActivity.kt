package com.fairyteam.fairyclient.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.fairyteam.fairyclient.R
import com.fairyteam.fairyclient.brom.AutoFlow
import com.fairyteam.fairyclient.brom.FlashJob
import com.fairyteam.fairyclient.brom.Mode
import com.fairyteam.fairyclient.brom.Phase
import com.fairyteam.fairyclient.data.FileStore
import com.fairyteam.fairyclient.data.FirmwareStore
import com.fairyteam.fairyclient.data.FlashImage
import com.fairyteam.fairyclient.data.ImageSource
import com.fairyteam.fairyclient.data.Kind
import com.fairyteam.fairyclient.data.humanSize
import com.fairyteam.fairyclient.databinding.ActivityMainBinding
import com.fairyteam.fairyclient.usb.UsbPermissions
import com.google.android.material.checkbox.MaterialCheckBox
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

class MainActivity : AppCompatActivity() {

    private enum class Page { HOME, MENU, CONSOLE, SETTINGS }

    private lateinit var b: ActivityMainBinding
    private lateinit var usb: UsbManager
    private lateinit var perms: UsbPermissions
    private lateinit var store: FileStore
    private lateinit var fw: FirmwareStore
    private lateinit var flow: AutoFlow

    private var armJob: Job? = null
    private var armed = false
    private var mode = Mode.FASTBOOT
    private var page = Page.HOME
    private var stepCount = 0
    private var fwImages: List<FlashImage> = emptyList()
    private val fwSelected = HashSet<String>()
    private val logLines = ArrayDeque<String>()

    private val pickers = Kind.values().associateWith { kind ->
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importFile(kind, uri)
        }
    }
    private val treePicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) { fw.setTree(uri); rescanFirmware() }
    }
    private val docsPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) { fw.addDocs(uris); rescanFirmware() }
    }

    private fun c(res: Int) = ContextCompat.getColor(this, res)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        store = FileStore(this)
        fw = FirmwareStore(this)
        perms = UsbPermissions(this, usb)
        perms.register()
        flow = AutoFlow(usb, perms, ::log, ::showPhase, ::showProgress, ::showStep, ::showInfo)

        // file pickers
        b.btnPickDa.setOnClickListener { pickers[Kind.DA]?.launch(arrayOf("*/*")) }
        b.btnPickBoot.setOnClickListener { pickers[Kind.BOOT]?.launch(arrayOf("*/*")) }
        b.btnPickVendorBoot.setOnClickListener { pickers[Kind.VENDOR_BOOT]?.launch(arrayOf("*/*")) }
        b.btnPickSingleImg.setOnClickListener { pickers[Kind.SINGLE_IMG]?.launch(arrayOf("*/*")) }
        b.btnPickFwFolder.setOnClickListener { treePicker.launch(null) }
        b.btnAddImages.setOnClickListener { docsPicker.launch(arrayOf("*/*")) }
        b.etPartitionName.doAfterTextChanged { refreshStartState() }

        // session
        b.btnStart.setOnClickListener { onStartPressed() }
        b.btnStop.setOnClickListener { armJob?.cancel() }

        // nav
        b.navHome.setOnClickListener { showPage(Page.HOME) }
        b.navMenu.setOnClickListener { showPage(Page.MENU) }
        b.navConsole.setOnClickListener { showPage(Page.CONSOLE) }
        b.navSettings.setOnClickListener { showPage(Page.SETTINGS) }
        onBackPressedDispatcher.addCallback(this) {
            if (page != Page.HOME) showPage(Page.HOME)
            else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
        }

        // menu
        b.menuForceBoot.setOnClickListener { chooseMode(Mode.FASTBOOT) }
        b.menuDa.setOnClickListener { chooseMode(Mode.DA) }
        b.menuFull.setOnClickListener { chooseMode(Mode.FULL_FIRMWARE) }
        b.menuSingle.setOnClickListener { chooseMode(Mode.SINGLE_IMG) }
        b.menuReset.setOnClickListener { chooseMode(Mode.RESET_DEVICE) }

        // console + settings
        b.btnCopyLog.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Fairyclient log", logLines.joinToString("\n")))
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show()
        }
        b.btnClearLog.setOnClickListener { logLines.clear(); b.consoleText.text = "" }
        b.btnClear.setOnClickListener {
            if (armed) return@setOnClickListener
            store.clear(); fw.clear()
            fwImages = emptyList(); fwSelected.clear()
            renderFw(); refreshFiles()
            log("Saved files cleared.")
        }
        b.rowAbout.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }
        b.rowTelegram.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.telegram_url))))
        }

        resetInfo()
        showPhase(Phase.IDLE, "Session stopped", "Pick an action, then press START")
        showProgress(0)
        applyModeUi()
        showPage(Page.HOME)
        rescanFirmware()
        log("Ready. Choose an action in Menu, pick its files on Home, press START, then plug the phone in.")
        log("Tip: when Android asks what to open for the USB device, choose Fairyclient and tick \u201CUse by default\u201D.")

        // Launched by the phone itself being plugged in → arm immediately.
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) startArm()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED && !armed) startArm()
    }

    // ---- pages -----------------------------------------------------------

    private fun showPage(p: Page) {
        page = p
        b.pageHome.isVisible = p == Page.HOME
        b.pageMenu.isVisible = p == Page.MENU
        b.pageConsole.isVisible = p == Page.CONSOLE
        b.pageSettings.isVisible = p == Page.SETTINGS

        TransitionManager.beginDelayedTransition(b.navPill, AutoTransition().setDuration(220))
        val items = listOf(
            Triple(b.navHome, b.navHomeLbl to b.navHomeIcon, Page.HOME),
            Triple(b.navMenu, b.navMenuLbl to b.navMenuIcon, Page.MENU),
            Triple(b.navConsole, b.navConsoleLbl to b.navConsoleIcon, Page.CONSOLE),
            Triple(b.navSettings, b.navSettingsLbl to b.navSettingsIcon, Page.SETTINGS)
        )
        for ((item, parts, pg) in items) {
            val sel = pg == p
            val lbl: TextView = parts.first
            val icon: ImageView = parts.second
            lbl.isVisible = sel
            item.setBackgroundResource(if (sel) R.drawable.nav_item_active else 0)
            icon.imageTintList = ColorStateList.valueOf(c(if (sel) R.color.text_primary else R.color.text_secondary))
        }
        if (p == Page.CONSOLE) b.consoleScroll.post { b.consoleScroll.fullScroll(View.FOCUS_DOWN) }
        if (p == Page.SETTINGS) refreshFiles()
    }

    private fun chooseMode(m: Mode) {
        if (armed) {
            Toast.makeText(this, "Stop the running session first", Toast.LENGTH_SHORT).show()
            return
        }
        mode = m
        applyModeUi()
        showPage(Page.HOME)
    }

    // ---- mode UI ---------------------------------------------------------

    private fun modeTitle(m: Mode) = when (m) {
        Mode.FASTBOOT -> "Force bootloader"
        Mode.DA -> "DA / BROM"
        Mode.FULL_FIRMWARE -> "Full firmware flash"
        Mode.SINGLE_IMG -> "Single IMG flash"
        Mode.RESET_DEVICE -> "Reset device"
    }

    private fun applyModeUi() {
        b.rowDa.isVisible = mode == Mode.DA
        b.rowBoot.isVisible = mode == Mode.FASTBOOT
        b.rowVendorBoot.isVisible = mode == Mode.FASTBOOT
        b.rowSingle.isVisible = mode == Mode.SINGLE_IMG
        b.rowFull.isVisible = mode == Mode.FULL_FIRMWARE
        b.rowResetWarning.isVisible = mode == Mode.RESET_DEVICE

        b.tvActionTitle.text = modeTitle(mode)
        b.valAction.text = modeTitle(mode)
        b.tvModeHint.text = when (mode) {
            Mode.FASTBOOT -> "Catches the phone in Preloader, forces fastboot, then flashes boot and vendor_boot."
            Mode.DA -> "BROM handshake, chip ID, security flags, then uploads DA1 and jumps to it. Writing partitions through the DA is not implemented."
            Mode.FULL_FIRMWARE -> "Forces fastboot, then flashes every ticked image from your firmware folder, partition by partition. Big images are split automatically."
            Mode.SINGLE_IMG -> "Forces fastboot, then writes one image to the one partition you name."
            Mode.RESET_DEVICE -> "Forces fastboot, then erases userdata and cache."
        }

        val labels = if (mode == Mode.DA)
            listOf("USB\nDetected", "BROM\nHandshake", "Sending\nDA", "DA\nReady")
        else
            listOf("USB\nDetected", "Preloader\nRequest", "Fastboot\nUp", "Flash\nDone")
        listOf(b.step1Lbl, b.step2Lbl, b.step3Lbl, b.step4Lbl).forEachIndexed { i, tv -> tv.text = labels[i] }

        listOf(
            b.menuForceBoot to Mode.FASTBOOT, b.menuDa to Mode.DA, b.menuFull to Mode.FULL_FIRMWARE,
            b.menuSingle to Mode.SINGLE_IMG, b.menuReset to Mode.RESET_DEVICE
        ).forEach { (v, m) ->
            v.setBackgroundResource(if (m == mode) R.drawable.glass_card_selected else R.drawable.glass_card)
        }
        refreshFiles()
        refreshStartState()
    }

    private fun refreshStartState() {
        val ready: Boolean
        val hint: String
        when (mode) {
            Mode.DA -> {
                ready = store.file(Kind.DA) != null
                hint = if (ready) "" else "Select a DA file to start a session."
            }
            Mode.SINGLE_IMG -> {
                val name = b.etPartitionName.text?.toString()?.trim()
                ready = !name.isNullOrEmpty() && store.file(Kind.SINGLE_IMG) != null
                hint = if (ready) "" else "Enter a partition name and select an image."
            }
            Mode.FULL_FIRMWARE -> {
                ready = true
                hint = if (fwSelected.isEmpty()) "No images ticked — the phone will only be put into fastboot." else ""
            }
            Mode.FASTBOOT -> {
                ready = true
                hint = if (store.file(Kind.BOOT) == null && store.file(Kind.VENDOR_BOOT) == null)
                    "No images selected — the phone will only be put into fastboot." else ""
            }
            Mode.RESET_DEVICE -> { ready = true; hint = "" }
        }
        b.btnStart.isEnabled = ready && !armed
        b.btnStop.isEnabled = armed
        b.btnStart.text = if (mode == Mode.RESET_DEVICE) "START (ERASE)" else "START"
        b.tvStartHint.text = if (armed) "" else hint
    }

    // ---- start / stop ----------------------------------------------------

    private fun onStartPressed() {
        if (armed) return
        when {
            mode == Mode.RESET_DEVICE -> AlertDialog.Builder(this)
                .setTitle("Erase this device?")
                .setMessage("This wipes userdata and cache. It cannot be undone. Continue?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Erase") { _, _ -> startArm() }
                .show()
            mode == Mode.FULL_FIRMWARE && fwSelected.isNotEmpty() -> {
                val names = fwImages.filter { it.partition in fwSelected }.map { it.partition }
                val shown = names.take(14).joinToString(", ") + if (names.size > 14) " … (+${names.size - 14})" else ""
                AlertDialog.Builder(this)
                    .setTitle("Flash ${names.size} images?")
                    .setMessage("Partitions: $shown\n\nWrong or mismatched images can brick the phone. Continue?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Flash") { _, _ -> startArm() }
                    .show()
            }
            else -> startArm()
        }
    }

    private fun fileImage(partition: String, f: File) =
        FlashImage(partition, listOf(ImageSource(f.name, f.length()) { FileInputStream(f) }))

    private fun buildImages(partitionName: String?): List<FlashImage> = when (mode) {
        Mode.FASTBOOT -> listOfNotNull(
            store.file(Kind.BOOT)?.let { fileImage("boot", it) },
            store.file(Kind.VENDOR_BOOT)?.let { fileImage("vendor_boot", it) }
        )
        Mode.FULL_FIRMWARE -> fwImages.filter { it.partition in fwSelected }
        Mode.SINGLE_IMG -> {
            val f = store.file(Kind.SINGLE_IMG)
            if (f != null && !partitionName.isNullOrEmpty()) listOf(fileImage(partitionName, f)) else emptyList()
        }
        else -> emptyList()
    }

    private fun startArm() {
        val da = store.file(Kind.DA)
        if (mode == Mode.DA && da == null) {
            showPhase(Phase.FAILED, "DA file missing", "Select a DA file first.")
            return
        }
        val partitionName = b.etPartitionName.text?.toString()?.trim()
        if (mode == Mode.SINGLE_IMG && (partitionName.isNullOrEmpty() || store.file(Kind.SINGLE_IMG) == null)) {
            showPhase(Phase.FAILED, "Missing info", "Single IMG needs a partition name and an image file.")
            return
        }
        val job = FlashJob(mode, da, buildImages(partitionName))
        resetInfo()
        setArmed(true)
        armJob = lifecycleScope.launch {
            try {
                flow.run(job)
            } catch (e: CancellationException) {
                showPhase(Phase.IDLE, "Session stopped", "Press START to arm again.")
                showProgress(0)
                throw e
            } finally {
                setArmed(false)
            }
        }
    }

    private fun setArmed(a: Boolean) {
        armed = a
        if (a) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        refreshStartState()
        showStep(stepCount)
    }

    // ---- files -----------------------------------------------------------

    private fun importFile(kind: Kind, uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { store.import(kind, uri) }
            log(if (ok) "${kind.label} saved." else "Could not read ${kind.label}.")
            refreshFiles()
            refreshStartState()
        }
    }

    private fun refreshFiles() {
        fun set(tv: TextView, k: Kind) {
            val d = store.describe(k)
            tv.text = d ?: "Not selected"
            tv.setTextColor(c(if (d != null) R.color.ok else R.color.text_primary))
        }
        set(b.tvDaName, Kind.DA)
        set(b.tvBootName, Kind.BOOT)
        set(b.tvVendorBootName, Kind.VENDOR_BOOT)
        set(b.tvSingleImgName, Kind.SINGLE_IMG)
        b.tvFwSource.text = fw.describe() ?: "Not selected"
        val saved = Kind.values().count { store.file(it) != null }
        b.tvStorageInfo.text = "$saved saved file(s) in private app storage" +
            (fw.describe()?.let { "\nFirmware: $it" } ?: "") +
            "\nFirmware images are read straight from your storage and never copied."
    }

    private fun rescanFirmware() {
        b.tvFwSummary.text = "Scanning…"
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) {
                try { fw.scan() } catch (e: Exception) { emptyList() }
            }
            fwImages = list
            fwSelected.clear()
            list.filter { it.defaultOn }.forEach { fwSelected.add(it.partition) }
            renderFw()
            refreshFiles()
            refreshStartState()
            if (list.isNotEmpty()) log("Firmware: ${list.size} image(s) found.")
        }
    }

    private fun renderFw() {
        b.fwList.removeAllViews()
        if (fwImages.isEmpty()) {
            b.tvFwSummary.text = if (fw.describe() == null)
                "Select the extracted firmware folder (boot.img, super.img, vbmeta.img …) or add image files."
            else "No .img files found in the selection."
            return
        }
        for (img in fwImages) {
            val cb = MaterialCheckBox(this)
            cb.text = buildString {
                append(img.partition).append("  ·  ").append(humanSize(img.totalSize))
                if (img.sources.size > 1) append("  ·  ").append(img.sources.size).append(" chunks")
                img.note?.let { append("  ·  ").append(it) }
            }
            cb.setTextColor(c(R.color.text_primary))
            cb.textSize = 14f
            cb.buttonTintList = ColorStateList.valueOf(c(R.color.accent))
            cb.isChecked = img.partition in fwSelected
            cb.setOnCheckedChangeListener { _, on ->
                if (on) fwSelected.add(img.partition) else fwSelected.remove(img.partition)
                updateFwSummary()
                refreshStartState()
            }
            b.fwList.addView(
                cb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        updateFwSummary()
    }

    private fun updateFwSummary() {
        val picked = fwImages.filter { it.partition in fwSelected }
        b.tvFwSummary.text = "${picked.size} of ${fwImages.size} images ticked · ${humanSize(picked.sumOf { it.totalSize })}"
    }

    // ---- UI callbacks (safe from any thread) -----------------------------

    private fun ui(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else runOnUiThread { block() }
    }

    private fun log(line: String) = ui {
        logLines.addLast(line)
        while (logLines.size > 400) logLines.removeFirst()
        b.consoleText.text = logLines.joinToString("\n")
        b.consoleScroll.post { b.consoleScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showPhase(p: Phase, title: String, sub: String) = ui {
        b.valStatus.text = title
        b.valStatusSub.text = sub
        b.valStatus.setTextColor(
            c(
                when (p) {
                    Phase.DONE -> R.color.ok
                    Phase.WARN -> R.color.warn
                    Phase.FAILED -> R.color.danger
                    Phase.WORKING, Phase.CONNECTING -> R.color.info
                    else -> R.color.text_primary
                }
            )
        )
        b.valSession.text = when (p) {
            Phase.IDLE -> "STOPPED"
            Phase.WAITING -> "ARMED"
            Phase.CONNECTING, Phase.WORKING -> "RUNNING"
            Phase.DONE, Phase.WARN -> "DONE"
            Phase.FAILED -> "FAILED"
        }
    }

    /** -1 = indeterminate, 0..100 = percent. */
    private fun showProgress(pct: Int) = ui {
        if (pct < 0) {
            if (!b.progress.isIndeterminate) b.progress.isIndeterminate = true
        } else {
            if (b.progress.isIndeterminate) b.progress.isIndeterminate = false
            b.progress.setProgressCompat(pct.coerceIn(0, 100), false)
        }
    }

    private fun showStep(n: Int) = ui {
        stepCount = n
        val dots = listOf(b.step1Dot, b.step2Dot, b.step3Dot, b.step4Dot)
        val lbls = listOf(b.step1Lbl, b.step2Lbl, b.step3Lbl, b.step4Lbl)
        val lines = listOf(b.line1, b.line2, b.line3)
        dots.forEachIndexed { i, d ->
            d.setBackgroundResource(
                when {
                    i < n -> R.drawable.dot_on
                    i == n && armed -> R.drawable.dot_active
                    else -> R.drawable.dot_off
                }
            )
        }
        lbls.forEachIndexed { i, l -> l.setTextColor(c(if (i < n) R.color.text_primary else R.color.text_secondary)) }
        lines.forEachIndexed { i, ln -> ln.setBackgroundColor(if (i < n - 1) c(R.color.accent) else 0x33FFFFFF) }
    }

    private fun showInfo(key: String, value: String) = ui {
        when (key) {
            "usbmode" -> b.valMode.text = value
            "vidpid" -> b.valVidPid.text = value
            "cpu" -> b.valCpu.text = value
            "product" -> b.valProduct.text = value
            "slot" -> b.valSlot.text = value
            "unlocked" -> b.valUnlocked.text = value.uppercase()
            "maxdl" -> b.valMaxDl.text = value
            "hw" -> b.valHw.text = value
            "sbc" -> paintSecurity(b.valSbc, value)
            "sla" -> paintSecurity(b.valSla, value)
            "daa" -> paintSecurity(b.valDaa, value)
        }
    }

    private fun paintSecurity(tv: TextView, v: String) {
        tv.text = v
        tv.setTextColor(c(if (v == "ON") R.color.warn else R.color.ok))
    }

    private fun resetInfo() = ui {
        b.valMode.text = "NO DEVICE"
        listOf(b.valCpu, b.valVidPid, b.valProduct, b.valSlot, b.valUnlocked, b.valMaxDl, b.valHw)
            .forEach { it.text = "—" }
        listOf(b.valSbc, b.valSla, b.valDaa).forEach { it.text = "—"; it.setTextColor(c(R.color.text_primary)) }
        showStep(0)
    }

    override fun onDestroy() {
        super.onDestroy()
        perms.unregister()
    }
}
