package com.fairyteam.fairyclient.data

import java.io.InputStream

/** One readable file (a raw/sparse image or a single *_sparsechunk.N piece). */
class ImageSource(val name: String, val size: Long, val open: () -> InputStream)

/**
 * Something that gets flashed to one partition. Normally one source; a vendor
 * "super.img_sparsechunk.0..N" set is one FlashImage with several sources, flashed in order.
 */
class FlashImage(
    val partition: String,
    val sources: List<ImageSource>,
    val defaultOn: Boolean = true,
    val note: String? = null
) {
    val totalSize: Long get() = sources.sumOf { it.size }
}

fun humanSize(b: Long): String = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
    b >= 1L shl 10 -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}
