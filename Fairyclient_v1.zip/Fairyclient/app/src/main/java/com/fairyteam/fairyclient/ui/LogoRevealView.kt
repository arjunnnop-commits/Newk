package com.fairyteam.fairyclient.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import com.fairyteam.fairyclient.R

/**
 * Draws the Fairy logo with a left-to-right "ink" reveal, then a slow red glow pulse behind it.
 */
class LogoRevealView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val logo: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.logo_mark)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()

    private var progress = 0f
    private var pulse = 0f
    private var reveal: ValueAnimator? = null
    private var breathe: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        reveal = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1300
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
        breathe = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        reveal?.cancel(); breathe?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f

        val glowAlpha = (0.30f + 0.25f * pulse) * minOf(1f, progress * 2f)
        glowPaint.shader = RadialGradient(
            cx, cy, s * 0.65f,
            Color.argb((glowAlpha * 255).toInt(), 200, 18, 32), Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, s * 0.65f, glowPaint)

        val layer = c.saveLayer(0f, 0f, w, h, null)
        dst.set(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f)
        c.drawBitmap(logo, null, dst, paint)
        if (progress < 1f) {
            val edge = (progress * 1.5f - 0.25f) * w
            maskPaint.shader = LinearGradient(
                edge - w * 0.25f, 0f, edge, 0f,
                Color.WHITE, Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h, maskPaint)
        }
        c.restoreToCount(layer)
    }
}
