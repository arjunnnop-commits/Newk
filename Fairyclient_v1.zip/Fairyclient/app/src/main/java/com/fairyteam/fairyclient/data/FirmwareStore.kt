package com.fairyteam.fairyclient.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import java.io.IOException

/**
 * Remembers a firmware folder (and/or individually added image files) and turns them into the
 * list of partitions to flash. Nothing is copied: images are streamed straight from storage at
 * flash time, so multi-GB firmware does not eat app storage.
 *
 *  boot.img                      -> partition "boot"
 *  super.img_sparsechunk.0 … N   -> partition "super", chunks flashed in order
 */
class FirmwareStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("fairy_fw", Context.MODE_PRIVATE)

    private class Entry(val name: String, val size: Long, val uri: Uri)

    fun setTree(uri: Uri) {
        persist(uri)
        prefs.edit().putString("tree", uri.toString()).apply()
    }

    fun addDocs(uris: List<Uri>) {
        val cur = (prefs.getStringSet("docs", emptySet()) ?: emptySet()).toMutableSet()
        for (u in uris) { persist(u); cur.add(u.toString()) }
        prefs.edit().putStringSet("docs", cur).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    fun describe(): String? {
        val tree = prefs.getString("tree", null)
        val docs = prefs.getStringSet("docs", emptySet())?.size ?: 0
        val parts = ArrayList<String>()
        if (tree != null) {
            parts += "Folder: " + (DocumentFile.fromTreeUri(ctx, Uri.parse(tree))?.name ?: "selected")
        }
        if (docs > 0) parts += "$docs added file(s)"
        return if (parts.isEmpty()) null else parts.joinToString("  +  ")
    }

    fun scan(): List<FlashImage> {
        val entries = ArrayList<Entry>()
        prefs.getString("tree", null)?.let { t ->
            val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(t))
            if (dir != null && dir.canRead()) collect(dir, entries, 0)
        }
        for (s in prefs.getStringSet("docs", emptySet()) ?: emptySet()) {
            val u = Uri.parse(s)
            try {
                ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) {
                            val n = c.getString(0) ?: return@use
                            entries += Entry(n, c.getLong(1), u)
                        }
                    }
            } catch (_: Exception) {
            }
        }
        return group(entries)
    }

    private fun collect(dir: DocumentFile, out: MutableList<Entry>, depth: Int) {
        for (f in dir.listFiles()) {
            if (f.isDirectory) {
                if (depth < 2) collect(f, out, depth + 1)
            } else {
                val n = f.name ?: continue
                out += Entry(n, f.length(), f.uri)
            }
        }
    }

    private fun source(e: Entry) = ImageSource(e.name, e.size) {
        ctx.contentResolver.openInputStream(e.uri) ?: throw IOException("Cannot open ${e.name}")
    }

    private fun group(entries: List<Entry>): List<FlashImage> {
        val chunkRe = Regex("""^(.+?)\.img_sparsechunk\.(\d+)$""", RegexOption.IGNORE_CASE)
        val imgRe = Regex("""^(.+)\.img$""", RegexOption.IGNORE_CASE)

        val chunks = LinkedHashMap<String, MutableList<Pair<Int, Entry>>>()
        val whole = LinkedHashMap<String, Entry>()
        for (e in entries) {
            val cm = chunkRe.find(e.name)
            if (cm != null) {
                chunks.getOrPut(cm.groupValues[1]) { ArrayList() }.add(cm.groupValues[2].toInt() to e)
                continue
            }
            val im = imgRe.find(e.name) ?: continue
            val part = im.groupValues[1]
            if (part.startsWith("super_empty", true) || e.size <= 0L) continue
            whole[part] = e
        }

        val wipes = setOf("userdata", "metadata", "cache")
        val out = ArrayList<FlashImage>()
        for ((part, list) in chunks) {
            val srcs = list.sortedBy { it.first }.map { source(it.second) }
            out += FlashImage(part, srcs, part !in wipes)
            whole.remove(part)
        }
        for ((part, e) in whole) {
            val wipe = part in wipes
            out += FlashImage(part, listOf(source(e)), !wipe, if (wipe) "erases user data" else null)
        }
        // wipes last, everything else alphabetical
        return out.sortedWith(compareBy({ it.partition in wipes }, { it.partition }))
    }

    private fun persist(uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }
}
