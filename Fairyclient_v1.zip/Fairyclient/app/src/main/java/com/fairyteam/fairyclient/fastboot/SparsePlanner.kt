package com.fairyteam.fairyclient.fastboot

import com.fairyteam.fairyclient.data.FlashImage
import com.fairyteam.fairyclient.data.ImageSource
import com.fairyteam.fairyclient.data.humanSize
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Turns a FlashImage into the downloads that fit the bootloader's max-download-size.
 * A raw image bigger than the limit is cut into several Android-sparse files on the fly
 * (same trick the official fastboot uses): each piece carries DONT_CARE for everything
 * outside its own block range, so the pieces can be flashed one after another.
 * Nothing is written to disk.
 */
object SparsePlanner {
    private const val BLK = 4096
    private const val MAGIC = 0xED26FF3A.toInt()
    private const val CHUNK_RAW = 0xCAC1
    private const val CHUNK_DONT_CARE = 0xCAC3
    private const val HARD_LIMIT = 0x40000000L

    class Piece(val size: Long, val open: () -> InputStream)

    fun plan(img: FlashImage, maxDownload: Long?): List<Piece> {
        val limit = if (maxDownload == null || maxDownload <= 0) HARD_LIMIT else minOf(maxDownload, HARD_LIMIT)
        val pieces = ArrayList<Piece>()
        for (s in img.sources) {
            if (s.size <= limit) {
                pieces += Piece(s.size, s.open)
                continue
            }
            if (isSparse(s)) {
                throw IllegalStateException(
                    "${s.name} is already a sparse image bigger than the phone's download limit " +
                        "(${humanSize(limit)}). Use the vendor's *_sparsechunk files or re-split it."
                )
            }
            pieces += split(s, limit)
        }
        return pieces
    }

    private fun isSparse(s: ImageSource): Boolean = s.open().use { i ->
        val b = ByteArray(4)
        var n = 0
        while (n < 4) {
            val r = i.read(b, n, 4 - n)
            if (r < 0) return false
            n += r
        }
        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int == MAGIC
    }

    private fun split(s: ImageSource, limit: Long): List<Piece> {
        val totalBlks = (s.size + BLK - 1) / BLK
        val overhead = 28L + 3 * 12L
        val perPiece = ((limit - overhead) / BLK - 1).coerceAtLeast(1)
        val out = ArrayList<Piece>()
        var b0 = 0L
        while (b0 < totalBlks) {
            val b1 = minOf(totalBlks, b0 + perPiece)
            val chunks = 1 + (if (b0 > 0) 1 else 0) + (if (b1 < totalBlks) 1 else 0)
            val size = 28L + 12L * chunks + (b1 - b0) * BLK
            val from = b0
            val to = b1
            out += Piece(size) { SparseStream(s, totalBlks, from, to) }
            b0 = b1
        }
        return out
    }

    private fun skipFully(i: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val k = i.skip(left)
            if (k > 0) left -= k
            else {
                if (i.read() < 0) throw EOFException("image ended while seeking")
                left -= 1
            }
        }
    }

    private class SparseStream(
        private val src: ImageSource,
        totalBlks: Long,
        private val b0: Long,
        private val b1: Long
    ) : InputStream() {
        private val head: ByteArray
        private val tail: ByteArray
        private var headPos = 0
        private var tailPos = 0
        private var file: InputStream? = null
        private var rawLeft = (b1 - b0) * BLK
        private var filePos = b0 * BLK

        init {
            val hasBefore = b0 > 0
            val hasAfter = b1 < totalBlks
            val chunks = 1 + (if (hasBefore) 1 else 0) + (if (hasAfter) 1 else 0)
            val h = ByteBuffer.allocate(28 + 12 + 12).order(ByteOrder.LITTLE_ENDIAN)
            h.putInt(MAGIC)
            h.putShort(1); h.putShort(0)            // major, minor
            h.putShort(28); h.putShort(12)          // file header size, chunk header size
            h.putInt(BLK)
            h.putInt(totalBlks.toInt())
            h.putInt(chunks)
            h.putInt(0)                             // image checksum
            if (hasBefore) {
                h.putShort(CHUNK_DONT_CARE.toShort()); h.putShort(0)
                h.putInt(b0.toInt()); h.putInt(12)
            }
            h.putShort(CHUNK_RAW.toShort()); h.putShort(0)
            h.putInt((b1 - b0).toInt()); h.putInt((12L + (b1 - b0) * BLK).toInt())
            head = h.array().copyOf(h.position())

            val t = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN)
            if (hasAfter) {
                t.putShort(CHUNK_DONT_CARE.toShort()); t.putShort(0)
                t.putInt((totalBlks - b1).toInt()); t.putInt(12)
            }
            tail = t.array().copyOf(t.position())
        }

        override fun read(): Int {
            val one = ByteArray(1)
            val n = read(one, 0, 1)
            return if (n < 0) -1 else one[0].toInt() and 0xFF
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            if (headPos < head.size) {
                val n = minOf(len, head.size - headPos)
                System.arraycopy(head, headPos, b, off, n)
                headPos += n
                return n
            }
            if (rawLeft > 0) {
                val want = minOf(len.toLong(), rawLeft).toInt()
                if (filePos >= src.size) {          // zero padding up to the block boundary
                    java.util.Arrays.fill(b, off, off + want, 0)
                    rawLeft -= want; filePos += want
                    return want
                }
                val ins = file ?: openAt()
                val can = minOf(want.toLong(), src.size - filePos).toInt()
                val n = ins.read(b, off, can)
                if (n < 0) throw IOException("${src.name} ended early")
                rawLeft -= n; filePos += n
                return n
            }
            if (tailPos < tail.size) {
                val n = minOf(len, tail.size - tailPos)
                System.arraycopy(tail, tailPos, b, off, n)
                tailPos += n
                return n
            }
            return -1
        }

        private fun openAt(): InputStream {
            val i = src.open()
            skipFully(i, b0 * BLK)
            file = i
            return i
        }

        override fun close() {
            file?.close()
        }
    }
}
