package com.fairyteam.fairyclient.brom

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.SystemClock
import com.fairyteam.fairyclient.data.FlashImage
import com.fairyteam.fairyclient.data.humanSize
import com.fairyteam.fairyclient.fastboot.FastbootClient
import com.fairyteam.fairyclient.fastboot.SparsePlanner
import com.fairyteam.fairyclient.usb.UsbLink
import com.fairyteam.fairyclient.usb.UsbPermissions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File

/**
 * FASTBOOT       — force bootloader, then flash the images the job carries (boot / vendor_boot).
 * DA             — BROM handshake + DA1 upload (stage-1 only, see daStage()).
 * FULL_FIRMWARE  — force bootloader, then flash every selected image of a firmware set,
 *                   partition by partition (big raw images are split into sparse pieces).
 * SINGLE_IMG     — force bootloader, then flash exactly one named partition from one file.
 * RESET_DEVICE   — force bootloader, then fastboot-erase userdata + cache (factory data reset).
 */
enum class Mode { FASTBOOT, DA, FULL_FIRMWARE, SINGLE_IMG, RESET_DEVICE }
enum class Phase { IDLE, WAITING, CONNECTING, WORKING, DONE, WARN, FAILED }

data class FlashJob(
    val mode: Mode,
    val da: File?,
    /** What to write, in order. Empty = just reach the bootloader. */
    val images: List<FlashImage> = emptyList()
)

/**
 * SP-Flash-Tool-style "arm it and plug the phone in" pipeline.
 *
 *  - polls USB every ~15 ms, grabs the MediaTek device the moment it shows up
 *    (any PID, survives re-enumeration: 0003 BROM / 2000 / 20FF Preloader …)
 *  - FASTBOOT mode: forces the bootloader, then flashes via fastboot
 *  - DA mode: handshake → hw code → security flags → DA1 upload → jump
 */
class AutoFlow(
    private val usb: UsbManager,
    private val perms: UsbPermissions,
    private val log: (String) -> Unit,
    private val onPhase: (Phase, String, String) -> Unit,
    private val onProgress: (Int) -> Unit,
    /** number of completed connection steps, 0..4 */
    private val onStep: (Int) -> Unit = {},
    /** key/value device facts: usbmode, vidpid, product, slot, unlocked, maxdl, hw, sbc, sla, daa */
    private val onInfo: (String, String) -> Unit = { _, _ -> }
) {
    private enum class Kind { DONE, WARN, ABORT, RETRY }
    private data class Outcome(val kind: Kind, val title: String, val sub: String)

    companion object {
        const val MTK_VID = 0x0E8D
        const val PID_BROM = 0x0003
        private const val DA1_FALLBACK_ADDR = 0x200000L

        fun pidName(pid: Int) = when (pid) {
            0x0003 -> "BROM"
            0x2000, 0x20FF -> "Preloader"
            0x2001 -> "DA/Download"
            else -> "MediaTek"
        }
    }

    suspend fun run(job: FlashJob) {
        var attempt = 0
        while (currentCoroutineContext().isActive) {
            onProgress(0)
            onStep(0)
            onPhase(
                Phase.WAITING, "Waiting for device…",
                if (job.mode == Mode.DA) "Connect the phone in BROM mode"
                else "Connect the phone in BROM / Preloader mode"
            )
            val dev = waitForDevice(job.mode)
            attempt++
            onStep(1)
            onInfo("vidpid", "%04X:%04X".format(dev.vendorId, dev.productId))
            onInfo("usbmode", if (FastbootClient.isFastbootDevice(dev)) "FASTBOOT" else pidName(dev.productId).uppercase())
            onInfo("cpu", if (dev.vendorId == MTK_VID) "MediaTek" else "—")
            onPhase(Phase.CONNECTING, "Device caught", "${pidName(dev.productId)} · PID 0x${dev.productId.toString(16)} · try #$attempt")

            val out = try {
                withContext(Dispatchers.IO) { handle(dev, job) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log("Error: ${e.message}")
                Outcome(Kind.RETRY, "Error", e.message ?: "unknown")
            }

            when (out.kind) {
                Kind.DONE -> { onProgress(100); onPhase(Phase.DONE, out.title, out.sub); return }
                Kind.WARN -> { onPhase(Phase.WARN, out.title, out.sub); return }
                Kind.ABORT -> { onPhase(Phase.FAILED, out.title, out.sub); return }
                Kind.RETRY -> {
                    log("↻ ${out.title}: ${out.sub}")
                    onPhase(Phase.WAITING, "Retrying…", out.sub)
                    delay(400)
                }
            }
        }
    }

    // ---- device discovery ------------------------------------------------

    private suspend fun waitForDevice(mode: Mode): UsbDevice {
        while (true) {
            findDevice(mode)?.let { return it }
            delay(15)
        }
    }

    private fun findDevice(mode: Mode): UsbDevice? {
        val all = usb.deviceList.values
        if (mode != Mode.DA) all.firstOrNull { FastbootClient.isFastbootDevice(it) }?.let { return it }
        return all.firstOrNull { it.vendorId == MTK_VID && !FastbootClient.isFastbootDevice(it) }
    }

    private suspend fun waitForFastboot(timeoutMs: Long): UsbDevice? {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < end) {
            usb.deviceList.values.firstOrNull { FastbootClient.isFastbootDevice(it) }?.let { return it }
            delay(30)
        }
        return null
    }

    /** Re-fetches the device by name each time: after re-enumeration old objects are stale. */
    private suspend fun openLink(dev: UsbDevice, accept: (android.hardware.usb.UsbInterface) -> Boolean = { true }): UsbLink? {
        repeat(60) {
            val cur = usb.deviceList[dev.deviceName] ?: return null
            val l = UsbLink(usb, cur, accept)
            if (l.open()) return l
            delay(20)
        }
        return null
    }

    // ---- dispatch --------------------------------------------------------

    private suspend fun handle(dev: UsbDevice, job: FlashJob): Outcome {
        if (!perms.ensure(dev)) {
            return Outcome(Kind.RETRY, "USB permission", "Not granted — allow it (tick “always”) and replug")
        }
        if (FastbootClient.isFastbootDevice(dev)) return flashViaFastboot(dev, job)
        return when (job.mode) {
            Mode.DA -> daStage(dev, job)
            else -> forceBootloader(dev, job)
        }
    }

    // ---- FASTBOOT mode ---------------------------------------------------

    private suspend fun forceBootloader(dev: UsbDevice, job: FlashJob): Outcome {
        if (dev.productId == PID_BROM) {
            return Outcome(
                Kind.ABORT, "True BROM detected",
                "Boot-mode request only works in Preloader. In BROM use DA mode."
            )
        }
        log("${pidName(dev.productId)} caught (PID 0x${dev.productId.toString(16)}) — forcing bootloader…")
        onPhase(Phase.WORKING, "Forcing bootloader", "Sending FASTBOOT request to preloader")
        onProgress(-1)

        val link = openLink(dev) ?: return Outcome(Kind.RETRY, "USB", "Could not open the device (it re-enumerated)")
        var seenRx = false
        var reenumerated = false
        try {
            val payload = "FASTBOOT".toByteArray(Charsets.US_ASCII)
            val end = SystemClock.elapsedRealtime() + 10000
            while (SystemClock.elapsedRealtime() < end) {
                if (usb.deviceList[dev.deviceName] == null) { reenumerated = true; break }
                link.write(payload, 40)
                val rx = link.readAvailable(64, 4)
                if (rx != null && rx.isNotEmpty() && !seenRx) {
                    seenRx = true
                    log("Preloader says: " + String(rx, Charsets.US_ASCII).filter { it.code in 32..126 })
                }
                delay(2)
            }
        } finally {
            link.close()
        }
        if (!reenumerated) {
            return Outcome(Kind.RETRY, "No reaction", "Preloader ignored the request — re-enter BROM/Preloader")
        }
        onStep(2)
        log("Device left preloader — waiting for fastboot…")
        val fb = waitForFastboot(25000)
            ?: return Outcome(Kind.RETRY, "No fastboot", "Device re-enumerated but no fastboot interface appeared")
        log("Fastboot device up (PID 0x${fb.productId.toString(16)}).")
        return handle(fb, job)
    }

    private suspend fun flashViaFastboot(dev: UsbDevice, job: FlashJob): Outcome {
        onStep(3)
        onPhase(Phase.WORKING, "Fastboot connected", "Reading bootloader info")
        onProgress(-1)
        val link = openLink(dev) { FastbootClient.isFastbootInterface(it) }
            ?: return Outcome(Kind.RETRY, "USB", "Could not open fastboot interface")
        try {
            val fb = FastbootClient(link, log)
            fb.getvar("product")?.let { log("product: $it"); onInfo("product", it) }
            fb.getvar("current-slot")?.let { log("slot: $it"); onInfo("slot", it) }
            val unlocked = fb.getvar("unlocked")
            if (unlocked != null) { log("unlocked: $unlocked"); onInfo("unlocked", unlocked) }
            val maxDl = fb.getvar("max-download-size")?.trim()?.removePrefix("0x")?.toLongOrNull(16)
            if (maxDl != null) onInfo("maxdl", humanSize(maxDl))

            if (job.mode == Mode.RESET_DEVICE) return eraseDevice(fb)

            val images = job.images
            if (images.isEmpty()) {
                return Outcome(Kind.DONE, "Bootloader reached", "No images selected — device stays in fastboot")
            }

            val plans = ArrayList<Pair<FlashImage, List<SparsePlanner.Piece>>>()
            for (img in images) {
                val pieces = try {
                    SparsePlanner.plan(img, maxDl)
                } catch (e: IllegalStateException) {
                    return Outcome(Kind.ABORT, "Image problem", e.message ?: "Cannot split ${img.partition}")
                }
                plans += img to pieces
            }

            val total = plans.sumOf { p -> p.second.sumOf { it.size } }.coerceAtLeast(1)
            var done = 0L
            var index = 0
            for ((img, pieces) in plans) {
                index++
                val head = "[$index/${plans.size}] ${img.partition}"
                log("Flashing ${img.partition} (${humanSize(img.totalSize)})" +
                    (if (pieces.size > 1) " in ${pieces.size} parts" else "") + "…")
                for ((i, piece) in pieces.withIndex()) {
                    onPhase(
                        Phase.WORKING, "Flashing ${img.partition}",
                        if (pieces.size > 1) "$head · part ${i + 1}/${pieces.size}" else "$head · ${humanSize(img.totalSize)}"
                    )
                    val base = done
                    fb.flash(img.partition, piece.open(), piece.size) { sent ->
                        onProgress(((base + sent) * 100 / total).toInt())
                    }
                    done += piece.size
                }
                log("${img.partition} OK")
            }
            onPhase(Phase.WORKING, "Rebooting", "")
            fb.reboot()
            onStep(4)
            return Outcome(Kind.DONE, "Flash complete", "${images.size} image(s) written — device is rebooting")
        } catch (e: FastbootClient.FastbootException) {
            val locked = e.message?.contains("lock", true) == true
            return Outcome(
                Kind.ABORT, "Fastboot error",
                (e.message ?: "unknown") + if (locked) "  — bootloader is locked" else ""
            )
        } catch (e: java.io.IOException) {
            return Outcome(Kind.ABORT, "File error", e.message ?: "Could not read an image file")
        } finally {
            link.close()
        }
    }

    private fun eraseDevice(fb: FastbootClient): Outcome {
        onPhase(Phase.WORKING, "Erasing userdata", "This wipes apps and personal files, like a factory reset")
        onProgress(-1)
        log("Erasing userdata…")
        fb.command("erase:userdata", 120000)
        log("userdata erased.")
        try {
            log("Erasing cache…")
            fb.command("erase:cache", 60000)
            log("cache erased.")
        } catch (e: FastbootClient.FastbootException) {
            log("No separate cache partition (${e.message}) — skipping.")
        }
        onPhase(Phase.WORKING, "Rebooting", "")
        fb.reboot()
        onStep(4)
        return Outcome(Kind.DONE, "Device reset", "userdata wiped — device is rebooting")
    }

    // ---- DA mode ---------------------------------------------------------

    private suspend fun daStage(dev: UsbDevice, job: FlashJob): Outcome {
        val daFile = job.da ?: return Outcome(Kind.ABORT, "No DA file", "Pick a DA file first")
        log("${pidName(dev.productId)} caught (PID 0x${dev.productId.toString(16)}) — handshaking…")
        onPhase(Phase.WORKING, "BROM handshake", "Tight polling, up to 20 s")
        onProgress(-1)

        val link = openLink(dev) ?: return Outcome(Kind.RETRY, "USB", "Could not open the device (it re-enumerated)")
        try {
            val brom = BromProtocol(link)
            if (!brom.handshake(20000)) {
                return Outcome(Kind.RETRY, "Handshake failed", "Device left the BROM window — replug in BROM mode")
            }
            log("Handshake OK.")
            onStep(2)

            val hw = brom.getHwCode()
            log("HW code: 0x${hw.toString(16)}")
            onInfo("hw", "0x%04X".format(hw))
            try {
                val tc = brom.getTargetConfig()
                log("Security: $tc")
                onInfo("sbc", if (tc.sbc) "ON" else "OFF")
                onInfo("sla", if (tc.sla) "ON" else "OFF")
                onInfo("daa", if (tc.daa) "ON" else "OFF")
            } catch (e: Exception) {
                log("Target config unavailable (${e.message})")
            }

            val loader = DaLoader(daFile.readBytes())
            val addr: Long
            val sigLen: Long
            val payload: ByteArray
            if (loader.isContainer) {
                val entry = loader.find(hw)
                    ?: return Outcome(Kind.ABORT, "DA mismatch", "This DA has no loader for chip 0x${hw.toString(16)}")
                val r = entry.regions.getOrNull(1)
                    ?: return Outcome(Kind.ABORT, "DA unreadable", "Loader entry has no stage-1 region")
                addr = r.addr; sigLen = r.sigLen; payload = loader.bytes(r)
                log("DA1: addr=0x${addr.toString(16)} len=${payload.size} sig=$sigLen")
            } else {
                addr = DA1_FALLBACK_ADDR; sigLen = 0; payload = daFile.readBytes()
                log("DA is not an AllInOne container — sending as raw DA1 @0x${addr.toString(16)}")
            }

            onPhase(Phase.WORKING, "Uploading DA", "${payload.size / 1024} KB")
            brom.sendDa(addr, payload, sigLen) { onProgress(it) }
            log("DA accepted.")
            onStep(3)
            brom.jumpDa(addr)
            log("Jumped to DA.")

            var sync = -1
            for (i in 0 until 4) {
                sync = link.readByte(if (i == 0) 8000 else 300)
                if (sync == 0xC0 || sync < 0) break
            }
            if (sync != 0xC0) {
                return Outcome(Kind.ABORT, "DA did not start", "No sync byte after jump — wrong DA for this chip")
            }
            log("DA1 is running (sync 0xC0).")
            onStep(4)
            return Outcome(
                Kind.WARN, "DA stage 1 OK",
                "Chip talks to the DA. Partition writing through the DA is not implemented — use Force bootloader or Full firmware flash."
            )
        } catch (e: BromProtocol.BromException) {
            return Outcome(Kind.ABORT, "BROM error", e.message ?: "unknown")
        } finally {
            link.close()
        }
    }
}
