package com.fairyteam.fairyclient.ui

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.fairyteam.fairyclient.R

/** Logo ink-reveal, title fade-in, then hands off to MainActivity. */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val title = findViewById<TextView>(R.id.splashTitle)
        val tag = findViewById<TextView>(R.id.splashTag)
        ObjectAnimator.ofFloat(title, "alpha", 0f, 1f).apply { duration = 420; startDelay = 1000; start() }
        ObjectAnimator.ofFloat(tag, "alpha", 0f, 1f).apply { duration = 420; startDelay = 1250; start() }

        findViewById<View>(android.R.id.content).postDelayed({
            if (isFinishing) return@postDelayed
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2100)
    }
}
